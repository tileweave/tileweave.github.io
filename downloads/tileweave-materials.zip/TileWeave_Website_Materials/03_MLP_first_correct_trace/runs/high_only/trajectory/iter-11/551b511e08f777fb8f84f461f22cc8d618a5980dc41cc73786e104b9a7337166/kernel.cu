#include "tl_templates/ascend/common.h"
#include "acl/acl.h"
#include <runtime/rt_ffts.h>
using namespace Catlass;
using uint = unsigned int;
using uchar = unsigned char;
using ushort = unsigned short;

extern "C" __global__ __aicore__ void kernel_kernel( GM_ADDR A_handle,  GM_ADDR W_handle,  GM_ADDR C_handle,  GM_ADDR Scratch_handle, uint64_t fftsAddr) {
  KERNEL_TASK_TYPE_DEFAULT(KERNEL_TYPE_MIX_AIC_1_2);
  AscendC::TPipe pipe;

  AscendC::GlobalTensor<half> A;
  A.SetGlobalBuffer((__gm__ half*)A_handle);
  AscendC::GlobalTensor<float> W;
  W.SetGlobalBuffer((__gm__ float*)W_handle);
  AscendC::GlobalTensor<float> C;
  C.SetGlobalBuffer((__gm__ float*)C_handle);
  AscendC::GlobalTensor<half> Scratch;
  Scratch.SetGlobalBuffer((__gm__ half*)Scratch_handle);

  AscendC::TBuf<AscendC::TPosition::A2> ascend_l0a;
  pipe.InitBuffer(ascend_l0a, 65536);
  AscendC::TBuf<AscendC::TPosition::B2> ascend_l0b;
  pipe.InitBuffer(ascend_l0b, 65536);
  AscendC::TBuf<AscendC::TPosition::A1> ascend_l1; pipe.InitBuffer(ascend_l1, 524032);
  AscendC::TBuf<AscendC::TPosition::CO1> ascend_l0c; pipe.InitBuffer(ascend_l0c, 131072);
  AscendC::TBuf<AscendC::TPosition::VECCALC> ascend_ub; pipe.InitBuffer(ascend_ub, 196352);
  pipe.Destroy();
  auto bid = AscendC::GetBlockIdx();
  if ASCEND_IS_AIV {
    bid = bid / 2;
  }
  auto a = ascend_l1.GetWithOffset<half>(131072, 0);
  auto b = ascend_l1.GetWithOffset<half>(131072, 262144);
  auto c = ascend_l0c.GetWithOffset<float>(16384, 0);
  auto la = ascend_l0a.GetWithOffset<half>(32768, 0);
  auto lb = ascend_l0b.GetWithOffset<half>(32768, 0);
  auto wf = ascend_ub.GetWithOffset<float>(32768, 0);
  auto wh = ascend_ub.GetWithOffset<half>(32768, 131072);
  auto vid = AscendC::GetSubBlockIdx();
  if ASCEND_IS_AIC {
    for (int32_t task = 0; task < 7; ++task) {
      if (((task * 5) + (bid / 4)) < 32) {
        AscendC::SetFlag<AscendC::HardEvent::M_MTE1>(0);
        AscendC::SetFlag<AscendC::HardEvent::M_MTE1>(1);
        AscendC::SetFlag<AscendC::HardEvent::MTE1_MTE2>(2);
        AscendC::SetFlag<AscendC::HardEvent::MTE1_MTE2>(3);
        AscendC::WaitFlag<AscendC::HardEvent::MTE1_MTE2>(2);
        tl::ascend::copy_gm_to_l1<half, 128, 512>(a[0], A[0], 16384, 128, 512, true);
        AscendC::CrossCoreWaitFlag(0);
        tl::ascend::copy_gm_to_l1<half, 128, 512>(b[0], Scratch[(bid * 131072)], 512, 128, 512, true);
        AscendC::CrossCoreSetFlag<0x2, PIPE_MTE2>(2);
        AscendC::SetFlag<AscendC::HardEvent::MTE2_MTE1>(2);
        for (int32_t k = 0; k < 32; ++k) {
          if (k < 31) {
            AscendC::WaitFlag<AscendC::HardEvent::MTE1_MTE2>((((k + 1) % 2) + 2));
            tl::ascend::copy_gm_to_l1<half, 128, 512>(a[(((k + 1) % 2) * 65536)], A[((k * 512) + 512)], 16384, 128, 512, false);
            AscendC::CrossCoreWaitFlag(((k + 1) % 2));
            tl::ascend::copy_gm_to_l1<half, 128, 512>(b[(((k + 1) % 2) * 65536)], Scratch[((bid * 131072) + (((k + 1) % 2) * 65536))], 512, 128, 512, false);
            AscendC::CrossCoreSetFlag<0x2, PIPE_MTE2>((((k + 1) % 2) + 2));
            AscendC::SetFlag<AscendC::HardEvent::MTE2_MTE1>((((k + 1) % 2) + 2));
          }
          AscendC::WaitFlag<AscendC::HardEvent::MTE2_MTE1>(((k % 2) + 2));
          for (int32_t kk = 0; kk < 4; ++kk) {
            AscendC::WaitFlag<AscendC::HardEvent::M_MTE1>((kk % 2));
            tl::ascend::copy_l1_to_l0a<half, 128, 512, false>(la[((kk % 2) * 16384)], a[(((k % 2) * 65536) + (kk * 16384))], 128, 128);
            tl::ascend::copy_l1_to_l0b<half, 128, 512, true>(lb[((kk % 2) * 16384)], b[(((k % 2) * 65536) + (kk * 16384))], 128, 128);
            if (kk == 3) {
              AscendC::SetFlag<AscendC::HardEvent::MTE1_MTE2>(((k % 2) + 2));
            }
            AscendC::SetFlag<AscendC::HardEvent::MTE1_M>((kk % 2));
            AscendC::WaitFlag<AscendC::HardEvent::MTE1_M>((kk % 2));
            tl::ascend::mma<half, float, 128, 128>(la[((kk % 2) * 16384)],lb[((kk % 2) * 16384)],c[0], ((k == 0) && (kk == 0)), 128);
            AscendC::SetFlag<AscendC::HardEvent::M_MTE1>((kk % 2));
          }
        }
        AscendC::WaitFlag<AscendC::HardEvent::M_MTE1>(0);
        AscendC::WaitFlag<AscendC::HardEvent::M_MTE1>(1);
        AscendC::WaitFlag<AscendC::HardEvent::MTE1_MTE2>(2);
        AscendC::WaitFlag<AscendC::HardEvent::MTE1_MTE2>(3);
        AscendC::SetFlag<AscendC::HardEvent::M_FIX>(0);
        AscendC::WaitFlag<AscendC::HardEvent::M_FIX>(0);
        tl::ascend::copy_l0c_to_gm<float, float, layout::RowMajor, 128, 128, 0>(C[((task * 2560) + (bid * 128))], c[0], 16384, 128, 128, 0);
        AscendC::SetFlag<AscendC::HardEvent::FIX_M>(0);
        AscendC::WaitFlag<AscendC::HardEvent::FIX_M>(0);
      }
    }
  }
  if ASCEND_IS_AIV {
    for (int32_t task_1 = 0; task_1 < 7; ++task_1) {
      if (((task_1 * 5) + (bid / 4)) < 32) {
        AscendC::SetFlag<AscendC::HardEvent::V_MTE2>(0);
        AscendC::SetFlag<AscendC::HardEvent::V_MTE2>(1);
        AscendC::SetFlag<AscendC::HardEvent::MTE3_V>(0);
        AscendC::SetFlag<AscendC::HardEvent::MTE3_V>(1);
        AscendC::WaitFlag<AscendC::HardEvent::V_MTE2>(0);
        tl::ascend::copy_gm_to_ub<float, 512, 32>(wf[0], W[(((task_1 * 41943040) + (bid * 2097152)) + (vid * 1048576))], 16384, ((1 < (((512 - (vid * 2)) - (bid * 4)) - (task_1 * 80))) ? 32 : (((16384 - (vid * 64)) - (bid * 128)) - (task_1 * 2560))), 512, 0.000000e+00f);
        AscendC::SetFlag<AscendC::HardEvent::MTE2_V>(0);
        for (int32_t t = 0; t < 64; ++t) {
          if (t < 63) {
            AscendC::WaitFlag<AscendC::HardEvent::V_MTE2>(((t + 1) % 2));
            tl::ascend::copy_gm_to_ub<float, 512, 32>(wf[(((t + 1) % 2) * 16384)], W[(((((task_1 * 41943040) + (bid * 2097152)) + (vid * 1048576)) + (((t + 1) % 2) * 524288)) + (((t + 1) / 2) * 512))], 16384, ((-511 <= ((((0 - ((t + 1) % 2)) - (vid * 2)) - (bid * 4)) - (task_1 * 80))) ? 32 : ((((16384 - (((t + 1) % 2) * 32)) - (vid * 64)) - (bid * 128)) - (task_1 * 2560))), 512, 0.000000e+00f);
            AscendC::SetFlag<AscendC::HardEvent::MTE2_V>(((t + 1) % 2));
          }
          if (((t % 2) == 0) && (4 <= t)) {
            AscendC::CrossCoreWaitFlag((((t % 4) / 2) + 2));
          }
          AscendC::WaitFlag<AscendC::HardEvent::MTE2_V>((t % 2));
          AscendC::WaitFlag<AscendC::HardEvent::MTE3_V>((t % 2));
          tl::ascend::copy_ub_to_ub<half, float, 16384>(wh[((t % 2) * 16384)], wf[((t % 2) * 16384)], 32, 512, 512, 32, 512, 512);
          AscendC::SetFlag<AscendC::HardEvent::V_MTE2>((t % 2));
          AscendC::SetFlag<AscendC::HardEvent::V_MTE3>((t % 2));
          AscendC::WaitFlag<AscendC::HardEvent::V_MTE3>((t % 2));
          tl::ascend::copy_ub_to_gm<half, 512, 32>(Scratch[((((bid * 131072) + (((t % 4) / 2) * 65536)) + (vid * 32768)) + ((t % 2) * 16384))], wh[((t % 2) * 16384)], 512, 32, 512);
          AscendC::SetFlag<AscendC::HardEvent::MTE3_V>((t % 2));
          if ((t % 2) == 1) {
            AscendC::CrossCoreSetFlag<0x2, PIPE_MTE3>(((t % 4) / 2));
          }
        }
        AscendC::WaitFlag<AscendC::HardEvent::V_MTE2>(0);
        AscendC::WaitFlag<AscendC::HardEvent::V_MTE2>(1);
        AscendC::WaitFlag<AscendC::HardEvent::MTE3_V>(0);
        AscendC::WaitFlag<AscendC::HardEvent::MTE3_V>(1);
        AscendC::CrossCoreWaitFlag(2);
        AscendC::CrossCoreWaitFlag(3);
      }
    }
  }
}

void kernel_kernel_tiling() {
}

extern "C" void call(uint8_t* A_handle, uint8_t* W_handle, uint8_t* C_handle, uint8_t* Scratch_handle, aclrtStream stream) {
  uint32_t fftsLen{0};
  uint64_t fftsAddr{0};
  rtGetC2cCtrlAddr(&fftsAddr, &fftsLen);
  kernel_kernel_tiling();
  kernel_kernel<<<20, nullptr, stream>>>(A_handle, W_handle, C_handle, Scratch_handle, fftsAddr);
}
