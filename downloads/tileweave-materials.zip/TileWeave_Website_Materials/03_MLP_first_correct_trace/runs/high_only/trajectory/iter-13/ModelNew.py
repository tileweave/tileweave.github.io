import tilelang
import tilelang.language as T
from reference import nn


@tilelang.jit(out_idx=[-1], target='ascendc')
def convert(R, C):
    B = 16384
    @T.prim_func
    def kernel(X: T.Tensor((R*C,), 'float32'), Y: T.Tensor((R*C,), 'float16')):
        with T.Kernel(24, is_npu=True) as (bid, vid):
            a = T.alloc_ub((B,), 'float32')
            b = T.alloc_ub((B,), 'float16')
            with T.Scope('V'):
                for j in T.serial(T.ceildiv(R*C,48*B)):
                    pos=(j*48+bid*2+vid)*B
                    if pos < R*C:
                        T.copy(X[pos], a)
                        T.barrier_all()
                        T.copy(a, b)
                        T.barrier_all()
                        T.copy(b, Y[pos])
                        T.barrier_all()
    return kernel


@tilelang.jit(out_idx=[2], workspace_idx=[3], target='ascendc')
def product(M, N, K, BN=256, BK=256):
    BM=128
    LK=64
    @T.prim_func
    def kernel(A:T.Tensor((M,K),'float16'), W:T.Tensor((N,K),'float32'), C:T.Tensor((M,N),'float32'), Scratch:T.Tensor((N//BN,2,BN,BK),'float16')):
        with T.Kernel(N//BN,is_npu=True) as (bid,vid):
            a=T.alloc_L1((2,BM,BK),'float16')
            b=T.alloc_L1((2,BN,BK),'float16')
            la=T.alloc_L0A((2,BM,LK),'float16')
            lb=T.alloc_L0B((2,LK,BN),'float16')
            c=T.alloc_L0C((BM,BN),'float32')
            wf=T.alloc_ub((2,BN//4,BK),'float32')
            wh=T.alloc_ub((2,BN//4,BK),'float16')
            with T.Scope('C'):
                T.set_flag('m','mte1',0)
                T.set_flag('m','mte1',1)
                T.set_flag('mte1','mte2',2)
                T.set_flag('mte1','mte2',3)
                T.wait_flag('mte1','mte2',2)
                T.copy(A[0,0],a[0,:,:])
                T.wait_cross_flag(0)
                T.copy(Scratch[bid,0,0,0],b[0,:,:])
                T.set_cross_flag('MTE2',2)
                T.set_flag('mte2','mte1',2)
                for k in T.serial(K//BK):
                    if k+1<K//BK:
                        T.wait_flag('mte1','mte2',2+(k+1)%2)
                        T.copy(A[0,(k+1)*BK],a[(k+1)%2,:,:])
                        T.wait_cross_flag((k+1)%2)
                        T.copy(Scratch[bid,(k+1)%2,0,0],b[(k+1)%2,:,:])
                        T.set_cross_flag('MTE2',2+(k+1)%2)
                        T.set_flag('mte2','mte1',2+(k+1)%2)
                    T.wait_flag('mte2','mte1',2+k%2)
                    for kk in T.serial(BK//LK):
                        T.wait_flag('m','mte1',kk%2)
                        T.copy(a[k%2,0,kk*LK],la[kk%2,:,:])
                        T.copy(b[k%2,0,kk*LK],lb[kk%2,:,:],transpose=True)
                        if kk==BK//LK-1:
                            T.set_flag('mte1','mte2',2+k%2)
                        T.set_flag('mte1','m',kk%2)
                        T.wait_flag('mte1','m',kk%2)
                        T.mma(la[kk%2,:,:],lb[kk%2,:,:],c,init=T.And(k==0,kk==0))
                        T.set_flag('m','mte1',kk%2)
                T.wait_flag('m','mte1',0)
                T.wait_flag('m','mte1',1)
                T.wait_flag('mte1','mte2',2)
                T.wait_flag('mte1','mte2',3)
                T.set_flag('m','fix',0)
                T.wait_flag('m','fix',0)
                T.copy(c,C[0,bid*BN])
            with T.Scope('V'):
                T.set_flag('v','mte2',0)
                T.set_flag('v','mte2',1)
                T.set_flag('mte3','v',0)
                T.set_flag('mte3','v',1)
                T.wait_flag('v','mte2',0)
                T.copy(W[bid*BN+vid*(BN//2),0],wf[0,:,:])
                T.set_flag('mte2','v',0)
                for t in T.serial(2*K//BK):
                    if t+1<2*K//BK:
                        T.wait_flag('v','mte2',(t+1)%2)
                        T.copy(W[bid*BN+vid*(BN//2)+(t+1)%2*(BN//4),(t+1)//2*BK],wf[(t+1)%2,:,:])
                        T.set_flag('mte2','v',(t+1)%2)
                    if t%2==0 and t>=4:
                        T.wait_cross_flag(2+(t//2)%2)
                    T.wait_flag('mte2','v',t%2)
                    T.wait_flag('mte3','v',t%2)
                    T.copy(wf[t%2,:,:],wh[t%2,:,:])
                    T.set_flag('v','mte2',t%2)
                    T.set_flag('v','mte3',t%2)
                    T.wait_flag('v','mte3',t%2)
                    T.copy(wh[t%2,:,:],Scratch[bid,(t//2)%2,vid*(BN//2)+(t%2)*(BN//4),0])
                    T.set_flag('mte3','v',t%2)
                    if t%2==1:
                        T.set_cross_flag('MTE3',(t//2)%2)
                T.wait_flag('v','mte2',0)
                T.wait_flag('v','mte2',1)
                T.wait_flag('mte3','v',0)
                T.wait_flag('mte3','v',1)
                T.wait_cross_flag(2)
                T.wait_cross_flag(3)
    return kernel


@tilelang.jit(out_idx=[-1], target='ascendc')
def epilogue(M,N,activate):
    B=8192
    output_dtype="float16" if activate else "float32"
    @T.prim_func
    def kernel(X:T.Tensor((M,N),'float32'), Bias:T.Tensor((N,),'float32'), Y:T.Tensor((M,N),output_dtype)):
        with T.Kernel(M*N//(2*B),is_npu=True) as (bid,vid):
            a=T.alloc_ub((B,), 'float32')
            b=T.alloc_ub((B,), 'float32')
            out=T.alloc_ub((B,),output_dtype)
            with T.Scope('V'):
                row=(bid*2+vid)//(N//B)
                col=(bid*2+vid)%(N//B)*B
                T.copy(X[row,col],a)
                T.copy(Bias[col],b)
                T.barrier_all()
                for i in T.Parallel(B):
                    a[i]=a[i]+b[i]
                if activate:
                    for i in T.Parallel(B):
                        a[i]=T.max(a[i],0.0)
                T.barrier_all()
                T.copy(a,out)
                T.barrier_all()
                T.copy(out,Y[row,col])
    return kernel


class ModelNew(nn.Module):
    def __init__(self,input_size,layer_sizes,output_size):
        super().__init__()
        layers=[]
        previous=input_size
        for size in layer_sizes:
            layers.extend([nn.Linear(previous,size),nn.ReLU()])
            previous=size
        layers.append(nn.Linear(previous,output_size))
        self.network=nn.Sequential(*layers)

    def forward(self,x):
        x=convert(128,x.shape[1])(x.view(-1)).view(128,x.shape[1])
        for index in range(0,len(self.network),2):
            layer=self.network[index]
            n,k=layer.weight.shape
            c=product(128,n,k)(x,layer.weight)
            x=epilogue(128,n,index+1<len(self.network))(c,layer.bias)
        return x
