#include "tl_templates/ascend/common.h"
#include "acl/acl.h"
#include <runtime/rt_ffts.h>
using namespace Catlass;
using uint = unsigned int;
using uchar = unsigned char;
using ushort = unsigned short;

extern "C" __global__ __aicore__ void kernel_kernel( GM_ADDR A_handle,  GM_ADDR W_handle,  GM_ADDR C_handle,  GM_ADDR Scratch_handle, uint64_t fftsAddr) {
  KERNEL_TASK_TYPE_DEFAULT(KERNEL_TYPE_MIX_AIC_1_2);
  AscendC::TPipe pipe;

  AscendC::GlobalTensor<half> A;
  A.SetGlobalBuffer((__gm__ half*)A_handle);
  AscendC::GlobalTensor<float> W;
  W.SetGlobalBuffer((__gm__ float*)W_handle);
  AscendC::GlobalTensor<float> C;
  C.SetGlobalBuffer((__gm__ float*)C_handle);
  AscendC::GlobalTensor<half> Scratch;
  Scratch.SetGlobalBuffer((__gm__ half*)Scratch_handle);

  AscendC::TBuf<AscendC::TPosition::A2> ascend_l0a;
  pipe.InitBuffer(ascend_l0a, 65536);
  AscendC::TBuf<AscendC::TPosition::B2> ascend_l0b;
  pipe.InitBuffer(ascend_l0b, 65536);
  AscendC::TBuf<AscendC::TPosition::A1> ascend_l1; pipe.InitBuffer(ascend_l1, 524032);
  AscendC::TBuf<AscendC::TPosition::CO1> ascend_l0c; pipe.InitBuffer(ascend_l0c, 131072);
  AscendC::TBuf<AscendC::TPosition::VECCALC> ascend_ub; pipe.InitBuffer(ascend_ub, 196352);
  pipe.Destroy();
  auto bid = AscendC::GetBlockIdx();
  if ASCEND_IS_AIV {
    bid = bid / 2;
  }
  auto c = ascend_l0c.GetWithOffset<float>(8192, 0);
  auto a = ascend_l1.GetWithOffset<half>(65536, 0);
  auto b = ascend_l1.GetWithOffset<half>(32768, 131072);
  auto wf = ascend_ub.GetWithOffset<float>(16384, 0);
  auto wh = ascend_ub.GetWithOffset<half>(16384, 65536);
  auto vid = AscendC::GetSubBlockIdx();
  if ASCEND_IS_AIC {
    for (int32_t task = 0; task < 6; ++task) {
      if (((task * 3) + (bid / 8)) < 16) {
        for (int32_t k = 0; k < 32; ++k) {
          tl::ascend::copy_gm_to_l1<half, 128, 512>(a[0], A[(k * 512)], 16384, 128, 512, true);
          AscendC::CrossCoreWaitFlag((k % 2));
          tl::ascend::copy_gm_to_l1<half, 64, 512>(b[0], Scratch[((bid * 65536) + ((k % 2) * 32768))], 512, 64, 512, true);
          AscendC::PipeBarrier<PIPE_ALL>();
          tl::ascend::gemm_v0<half, float, 128, 64, 512, false, true, 128>(a[0], b[0], c[0], ascend_l0a, ascend_l0b, (k == 0), 64);
          AscendC::PipeBarrier<PIPE_ALL>();
          AscendC::CrossCoreSetFlag<0x2, PIPE_MTE2>(((k % 2) + 2));
        }
        tl::ascend::copy_l0c_to_gm<float, float, layout::RowMajor, 128, 64, 0>(C[((task * 1536) + (bid * 64))], c[0], 8192, 128, 64, 0);
      }
    }
  }
  if ASCEND_IS_AIV {
    for (int32_t task_1 = 0; task_1 < 6; ++task_1) {
      if (((task_1 * 3) + (bid / 8)) < 16) {
        for (int32_t k_1 = 0; k_1 < 32; ++k_1) {
          if (2 <= k_1) {
            AscendC::CrossCoreWaitFlag(((k_1 % 2) + 2));
          }
          tl::ascend::copy_gm_to_ub<float, 512, 32>(wf[0], W[((((task_1 * 25165824) + (bid * 1048576)) + (vid * 524288)) + (k_1 * 512))], 16384, ((-255 <= (((0 - vid) - (bid * 2)) - (task_1 * 48))) ? 32 : (((8192 - (vid * 32)) - (bid * 64)) - (task_1 * 1536))), 512, 0.000000e+00f);
          AscendC::PipeBarrier<PIPE_ALL>();
          tl::ascend::copy_ub_to_ub<half, float, 16384>(wh[0], wf[0], 32, 512, 512, 32, 512, 512);
          AscendC::PipeBarrier<PIPE_ALL>();
          tl::ascend::copy_ub_to_gm<half, 512, 32>(Scratch[(((bid * 65536) + ((k_1 % 2) * 32768)) + (vid * 16384))], wh[0], 512, 32, 512);
          AscendC::PipeBarrier<PIPE_ALL>();
          AscendC::CrossCoreSetFlag<0x2, PIPE_MTE3>((k_1 % 2));
        }
        AscendC::CrossCoreWaitFlag(2);
        AscendC::CrossCoreWaitFlag(3);
      }
    }
  }
}

void kernel_kernel_tiling() {
}

extern "C" void call(uint8_t* A_handle, uint8_t* W_handle, uint8_t* C_handle, uint8_t* Scratch_handle, aclrtStream stream) {
  uint32_t fftsLen{0};
  uint64_t fftsAddr{0};
  rtGetC2cCtrlAddr(&fftsAddr, &fftsLen);
  kernel_kernel_tiling();
  kernel_kernel<<<24, nullptr, stream>>>(A_handle, W_handle, C_handle, Scratch_handle, fftsAddr);
}
