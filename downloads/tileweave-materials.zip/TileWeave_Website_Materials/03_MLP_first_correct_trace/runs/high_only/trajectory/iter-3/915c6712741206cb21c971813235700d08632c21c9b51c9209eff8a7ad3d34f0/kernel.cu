#include "tl_templates/ascend/common.h"
#include "acl/acl.h"
#include <runtime/rt_ffts.h>
using namespace Catlass;
using uint = unsigned int;
using uchar = unsigned char;
using ushort = unsigned short;

extern "C" __global__ __aicore__ void kernel_kernel( GM_ADDR A_handle,  GM_ADDR W_handle,  GM_ADDR C_handle, uint64_t fftsAddr) {
  KERNEL_TASK_TYPE_DEFAULT(KERNEL_TYPE_MIX_AIC_1_2);
  AscendC::TPipe pipe;

  AscendC::GlobalTensor<half> A;
  A.SetGlobalBuffer((__gm__ half*)A_handle);
  AscendC::GlobalTensor<half> W;
  W.SetGlobalBuffer((__gm__ half*)W_handle);
  AscendC::GlobalTensor<float> C;
  C.SetGlobalBuffer((__gm__ float*)C_handle);

  AscendC::TBuf<AscendC::TPosition::A2> ascend_l0a;
  pipe.InitBuffer(ascend_l0a, 65536);
  AscendC::TBuf<AscendC::TPosition::B2> ascend_l0b;
  pipe.InitBuffer(ascend_l0b, 65536);
  AscendC::TBuf<AscendC::TPosition::A1> ascend_l1; pipe.InitBuffer(ascend_l1, 524032);
  AscendC::TBuf<AscendC::TPosition::CO1> ascend_l0c; pipe.InitBuffer(ascend_l0c, 131072);
  AscendC::TBuf<AscendC::TPosition::VECCALC> ascend_ub; pipe.InitBuffer(ascend_ub, 196352);
  pipe.Destroy();
  auto bid = AscendC::GetBlockIdx();
  if ASCEND_IS_AIV {
    bid = bid / 2;
  }
  auto a = ascend_l1.GetWithOffset<half>(65536, 0);
  auto b = ascend_l1.GetWithOffset<half>(65536, 131072);
  auto c = ascend_l0c.GetWithOffset<float>(16384, 0);
  if ASCEND_IS_AIC {
    tl::ascend::copy_gm_to_l1<half, 128, 256>(a[0], A[0], 16384, 128, 256, true);
    tl::ascend::copy_gm_to_l1<half, 128, 256>(b[0], W[(bid * 2097152)], 16384, 128, 256, true);
    for (int32_t k = 0; k < 63; ++k) {
      AscendC::PipeBarrier<PIPE_MTE2>();
      AscendC::SetFlag<AscendC::HardEvent::M_MTE2>(2);
      AscendC::WaitFlag<AscendC::HardEvent::M_MTE2>(2);
      tl::ascend::copy_gm_to_l1<half, 128, 256>(a[(((k + 1) % 2) * 32768)], A[((k * 256) + 256)], 16384, 128, 256, false);
      tl::ascend::copy_gm_to_l1<half, 128, 256>(b[(((k + 1) % 2) * 32768)], W[(((bid * 2097152) + (k * 256)) + 256)], 16384, 128, 256, false);
      AscendC::SetFlag<AscendC::HardEvent::MTE2_M>(1);
      AscendC::WaitFlag<AscendC::HardEvent::MTE2_M>(1);
      AscendC::PipeBarrier<PIPE_M>();
      tl::ascend::gemm_v0<half, float, 128, 128, 256, false, true, 128>(a[((k % 2) * 32768)], b[((k % 2) * 32768)], c[0], ascend_l0a, ascend_l0b, (k == 0), 128);
    }
    AscendC::PipeBarrier<PIPE_M>();
    tl::ascend::gemm_v0<half, float, 128, 128, 256, false, true, 128>(a[32768], b[32768], c[0], ascend_l0a, ascend_l0b, (bool)0, 128);
    AscendC::SetFlag<AscendC::HardEvent::M_FIX>(4);
    AscendC::WaitFlag<AscendC::HardEvent::M_FIX>(4);
    tl::ascend::copy_l0c_to_gm<float, float, layout::RowMajor, 128, 128, 0>(C[(bid * 128)], c[0], 8192, 128, 128, 0);
  }
}

void kernel_kernel_tiling() {
}

extern "C" void call(uint8_t* A_handle, uint8_t* W_handle, uint8_t* C_handle, aclrtStream stream) {
  uint32_t fftsLen{0};
  uint64_t fftsAddr{0};
  rtGetC2cCtrlAddr(&fftsAddr, &fftsLen);
  kernel_kernel_tiling();
  kernel_kernel<<<64, nullptr, stream>>>(A_handle, W_handle, C_handle, fftsAddr);
}
