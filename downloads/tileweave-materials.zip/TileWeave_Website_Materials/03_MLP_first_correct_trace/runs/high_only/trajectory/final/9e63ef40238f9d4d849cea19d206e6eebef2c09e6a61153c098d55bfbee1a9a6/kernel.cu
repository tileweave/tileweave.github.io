#include "tl_templates/ascend/common.h"
#include "acl/acl.h"
#include <runtime/rt_ffts.h>
using namespace Catlass;
using uint = unsigned int;
using uchar = unsigned char;
using ushort = unsigned short;

extern "C" __global__ __aicore__ void kernel_kernel( GM_ADDR X_handle,  GM_ADDR Bias_handle,  GM_ADDR Y_handle, uint64_t fftsAddr) {
  KERNEL_TASK_TYPE_DEFAULT(KERNEL_TYPE_MIX_AIC_1_2);
  AscendC::TPipe pipe;

  AscendC::GlobalTensor<float> X;
  X.SetGlobalBuffer((__gm__ float*)X_handle);
  AscendC::GlobalTensor<float> Bias;
  Bias.SetGlobalBuffer((__gm__ float*)Bias_handle);
  AscendC::GlobalTensor<float> Y;
  Y.SetGlobalBuffer((__gm__ float*)Y_handle);

  AscendC::TBuf<AscendC::TPosition::A2> ascend_l0a;
  pipe.InitBuffer(ascend_l0a, 65536);
  AscendC::TBuf<AscendC::TPosition::B2> ascend_l0b;
  pipe.InitBuffer(ascend_l0b, 65536);
  AscendC::TBuf<AscendC::TPosition::A1> ascend_l1; pipe.InitBuffer(ascend_l1, 524032);
  AscendC::TBuf<AscendC::TPosition::CO1> ascend_l0c; pipe.InitBuffer(ascend_l0c, 131072);
  AscendC::TBuf<AscendC::TPosition::VECCALC> ascend_ub; pipe.InitBuffer(ascend_ub, 196352);
  pipe.Destroy();
  auto bid = AscendC::GetBlockIdx();
  if ASCEND_IS_AIV {
    bid = bid / 2;
  }
  auto a = ascend_ub.GetWithOffset<float>(8192, 0);
  auto b = ascend_ub.GetWithOffset<float>(8192, 32768);
  auto out = ascend_ub.GetWithOffset<float>(8192, 65536);
  auto vid = AscendC::GetSubBlockIdx();
  if ASCEND_IS_AIV {
    tl::ascend::copy_gm_to_ub<float, 8192>(a[0], X[((bid * 16384) + (vid * 8192))], 1048576, 1, 8192, 0.000000e+00f);
    tl::ascend::copy_gm_to_ub<float, 8192>(b[0], Bias[0], 8192, 1, 8192, 0.000000e+00f);
    AscendC::PipeBarrier<PIPE_ALL>();
    AscendC::Add(a[0], a[0], b[0], 8192);
    AscendC::PipeBarrier<PIPE_ALL>();
    tl::ascend::copy_ub_to_ub<float, float, 8192>(out[0], a[0], 1, 8192, 8192, 1, 8192, 8192);
    AscendC::PipeBarrier<PIPE_ALL>();
    tl::ascend::copy_ub_to_gm<float, 8192>(Y[((bid * 16384) + (vid * 8192))], out[0], 1048576, 1, 8192);
  }
}

void kernel_kernel_tiling() {
}

extern "C" void call(uint8_t* X_handle, uint8_t* Bias_handle, uint8_t* Y_handle, aclrtStream stream) {
  uint32_t fftsLen{0};
  uint64_t fftsAddr{0};
  rtGetC2cCtrlAddr(&fftsAddr, &fftsLen);
  kernel_kernel_tiling();
  kernel_kernel<<<64, nullptr, stream>>>(X_handle, Bias_handle, Y_handle, fftsAddr);
}
