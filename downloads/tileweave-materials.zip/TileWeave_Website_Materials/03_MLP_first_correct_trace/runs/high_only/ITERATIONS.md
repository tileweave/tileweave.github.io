# High-stage baseline — complete evaluation sequence


All acquired evaluation snapshots are included. Numeric medians retain their historical case targets; five-sample blocks are generated. The original logs are external.

| Iteration | Stage | Status | Latency target (ms) | Speedup target | Notes |
|---|---|---|---:|---:|---|
| baseline | High | correct | 11.85558 | 0.39101081516045605 |  |
| iter-1-prelaunch | High | prelaunch_failed |  |  | Documented redirection failure before evaluation; no source snapshot or timing exists. |
| iter-2 | High | correct | 8.98902 | 0.5157024903715867 |  |
| iter-3 | High | correct | 6.7837 | 0.6833527426035939 |  |
| iter-4 | High | correct | 3.6119199999999996 | 1.28343374161111 |  |
| iter-5 | High | correct | 4.6285 | 1.0015469374527384 |  |
| iter-6 | High | correct | 3.3665599999999998 | 1.376972339717694 |  |
| iter-7 | High | correct | 3.01124 | 1.5394521858104966 |  |
| iter-8 | High | correct | 2.6633 | 1.740569969586603 |  |
| iter-9 | High | correct | 2.5524200000000006 | 1.8161822897485518 |  |
| iter-10 | High | correct | 2.52542 | 1.8355996230330003 | Historical trial checks passed, but this candidate was excluded after identifying a missing ownership fence. |
| iter-11 | High | correct | 2.5996799999999998 | 1.7831656203840474 |  |
| iter-12 | High | correct | 2.70748 | 1.7121677722457782 |  |
| iter-13 | High | correct | 2.9936000000000003 | 1.5485235168359164 |  |
| final | High | correct | 2.55466 | 1.8145898084285186 | Final validation of the restored selected candidate. |
