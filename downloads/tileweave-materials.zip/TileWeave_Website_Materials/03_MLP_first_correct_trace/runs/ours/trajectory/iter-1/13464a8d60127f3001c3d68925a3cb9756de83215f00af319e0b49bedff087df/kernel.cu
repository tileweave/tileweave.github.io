#include "tl_templates/ascend/common.h"
#include "acl/acl.h"
#include <runtime/rt_ffts.h>
using namespace Catlass;
using uint = unsigned int;
using uchar = unsigned char;
using ushort = unsigned short;

extern "C" __global__ __aicore__ void main_kernel( GM_ADDR X_handle,  GM_ADDR Y_handle, uint64_t fftsAddr) {
  KERNEL_TASK_TYPE_DEFAULT(KERNEL_TYPE_MIX_AIC_1_2);
  AscendC::TPipe pipe;

  AscendC::GlobalTensor<float> X;
  X.SetGlobalBuffer((__gm__ float*)X_handle);
  AscendC::GlobalTensor<half> Y;
  Y.SetGlobalBuffer((__gm__ half*)Y_handle);

  AscendC::TBuf<AscendC::TPosition::A2> ascend_l0a;
  pipe.InitBuffer(ascend_l0a, 65536);
  AscendC::TBuf<AscendC::TPosition::B2> ascend_l0b;
  pipe.InitBuffer(ascend_l0b, 65536);
  AscendC::TBuf<AscendC::TPosition::A1> ascend_l1; pipe.InitBuffer(ascend_l1, 524032);
  AscendC::TBuf<AscendC::TPosition::CO1> ascend_l0c; pipe.InitBuffer(ascend_l0c, 131072);
  AscendC::TBuf<AscendC::TPosition::VECCALC> ascend_ub; pipe.InitBuffer(ascend_ub, 196352);
  pipe.Destroy();
  auto cid = AscendC::GetBlockIdx();
  if ASCEND_IS_AIV {
    cid = cid / 2;
  }
  auto x = ascend_ub.GetWithOffset<float>(8192, 0);
  auto y = ascend_ub.GetWithOffset<half>(8192, 32768);
  auto vid = AscendC::GetSubBlockIdx();
  if ASCEND_IS_AIV {
    tl::ascend::copy_gm_to_ub<float, 8192>(x[0], X[((cid * 16384) + (vid * 8192))], 268435456, 1, 8192, 0.000000e+00f);
    AscendC::PipeBarrier<PIPE_ALL>();
    AscendC::Cast(y[0], x[0], AscendC::RoundMode::CAST_NONE, 8192);
    AscendC::PipeBarrier<PIPE_ALL>();
    tl::ascend::copy_ub_to_gm<half, 8192>(Y[((cid * 16384) + (vid * 8192))], y[0], 268435456, 1, 8192);
  }
}

void main_kernel_tiling() {
}

extern "C" void call(uint8_t* X_handle, uint8_t* Y_handle, aclrtStream stream) {
  uint32_t fftsLen{0};
  uint64_t fftsAddr{0};
  rtGetC2cCtrlAddr(&fftsAddr, &fftsLen);
  main_kernel_tiling();
  main_kernel<<<16384, nullptr, stream>>>(X_handle, Y_handle, fftsAddr);
}
