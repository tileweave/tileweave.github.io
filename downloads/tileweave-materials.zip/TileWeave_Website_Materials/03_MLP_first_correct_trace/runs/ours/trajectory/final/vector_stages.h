#include "tl_templates/ascend/common.h"
#include "acl/acl.h"
using namespace AscendC;
constexpr int B = VECTOR_B;
extern "C" __global__ __aicore__ void prepare_stage(GM_ADDR xp, GM_ADDR yp, GM_ADDR bp, GM_ADDR cp) {
  KERNEL_TASK_TYPE_DEFAULT(KERNEL_TYPE_MIX_AIC_1_2);
  TPipe pipe;
  TBuf<TPosition::VECCALC> ub; pipe.InitBuffer(ub, 10 * B);
  auto x = ub.GetWithOffset<float>(B, 0);
  auto y = ub.GetWithOffset<half>(B, 4 * B);
  auto bias = ub.GetWithOffset<float>(B, 6 * B);
  GlobalTensor<float> X; X.SetGlobalBuffer((__gm__ float*)xp);
  GlobalTensor<half> Y; Y.SetGlobalBuffer((__gm__ half*)yp);
  GlobalTensor<float> Bias; Bias.SetGlobalBuffer((__gm__ float*)bp);
  GlobalTensor<float> C; C.SetGlobalBuffer((__gm__ float*)cp);
  if ASCEND_IS_AIV {
    int offset = GetBlockIdx() * B;
    tl::ascend::copy_gm_to_ub<float, B>(x, X[offset], 128 * 16384, 1, B);
    if (offset < 128 * NEXT_N) {
      tl::ascend::copy_gm_to_ub<float, B>(bias, Bias[offset % NEXT_N], NEXT_N, 1, B);
    }
    PipeBarrier<PIPE_ALL>();
    if constexpr (APPLY_RELU) {
      Maxs(x, x, 0.0f, B);
      PipeBarrier<PIPE_V>();
    }
    Cast(y, x, RoundMode::CAST_NONE, B);
    PipeBarrier<PIPE_ALL>();
    tl::ascend::copy_ub_to_gm<half, B>(Y[offset], y, 128 * 16384, 1, B);
    if (offset < 128 * NEXT_N) {
      tl::ascend::copy_ub_to_gm<float, B>(C[offset], bias, 128 * NEXT_N, 1, B);
    }
    PipeBarrier<PIPE_ALL>();
  }
}
extern "C" void call(uint8_t* x, uint8_t* y, uint8_t* bias, uint8_t* c, aclrtStream stream) {
  prepare_stage<<<128 * 16384 / (2 * B), nullptr, stream>>>(x, y, bias, c);
}
