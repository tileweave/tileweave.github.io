#define OUT_N 8192
#include "fused_dense.h"
