#define APPLY_RELU 1
#define VECTOR_B 4096
#define NEXT_N 16384
#include "vector_stages.h"
