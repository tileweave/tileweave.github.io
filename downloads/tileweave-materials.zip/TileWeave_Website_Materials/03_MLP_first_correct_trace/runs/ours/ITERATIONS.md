# Ours / TileWeave — complete evaluation sequence


All acquired evaluation snapshots are included. Numeric medians retain their historical case targets; five-sample blocks are generated. The original logs are external.

| Iteration | Stage | Status | Latency target (ms) | Speedup target | Notes |
|---|---|---|---:|---:|---|
| iter-1 | High | failed |  |  | Compiler process failed before first correctness. |
| iter-2 | High | correct | 7.21562 | 0.6424479116139707 |  |
| iter-3 | High | correct | 6.0846599999999995 | 0.7618601532378144 |  |
| iter-4 | High | failed |  |  | High-level compilation failed for the cross-scope producer/consumer candidate. |
| iter-5 | Low | failed |  |  | Native candidate failed during device execution; no successful latency. |
| iter-6 | Low | failed |  |  | Native retry failed; no successful latency. |
| iter-7 | Low | correct | 3.56616 | 1.2999024160441481 |  |
| iter-8 | Low | correct | 3.4862399999999996 | 1.3297019138097206 |  |
| iter-9 | Low | correct | 3.3328200000000003 | 1.3909122004788734 |  |
| iter-10 | Low | correct | 5.51818 | 0.8400704580133304 |  |
| iter-11 | Low | correct | 4.9360599999999994 | 0.9391417446303327 |  |
| iter-12 | Low | correct | 3.2509600000000005 | 1.4259357236016434 |  |
| iter-13 | Low | correct | 2.94708 | 1.5729671403558776 |  |
| iter-14 | Low | correct | 2.8052200000000003 | 1.6525121024375982 |  |
| iter-15 | Low | correct | 3.12372 | 1.4840190542046021 |  |
| iter-16 | Low | correct | 2.7328 | 1.696304156908665 |  |
| iter-17 | Low | correct | 3.0113 | 1.539421512303656 |  |
| iter-18 | Low | correct | 2.6717999999999997 | 1.7350325623175389 |  |
| iter-19 | Low | correct | 2.6009800000000003 | 1.7822743735053708 |  |
| iter-20 | Low | correct | 2.34682 | 1.97529422793397 |  |
| iter-21 | Low | correct | 2.2422400000000002 | 2.06742364778079 |  |
| iter-22 | Low | correct | 2.20946 | 2.0980963674381976 |  |
| iter-23 | Low | correct | 2.19574 | 2.111206244819514 |  |
| iter-24 | Low | correct | 2.2423200000000003 | 2.067349887616397 |  |
| iter-25 | Low | correct | 2.19594 | 2.1110139621301127 |  |
| iter-26 | Low | correct | 2.1767000000000003 | 2.129673358754077 |  |
| iter-27 | Low | correct | 2.1938799999999996 | 2.112996152934527 |  |
| final | Low | correct | 2.18364 | 2.122904874429851 | Final validation of the restored selected candidate. |
