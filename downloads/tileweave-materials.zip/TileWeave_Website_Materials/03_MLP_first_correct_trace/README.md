# MLP traces — High-stage baseline and TileWeave

Evaluation sequences and candidate snapshots for the Ascend/Astra MLP example on PDF page 13, Section 4.3.

| Method | First correctness | Final latency | Reference latency | Final speedup |
|---|---:|---:|---:|---:|
| High-stage baseline | 4.13 min | 2.55466 ms | 4.63566 ms | 1.81459× |
| TileWeave | 5.41 min | 2.18364 ms | 4.63566 ms | 2.12290× |

`runs/high_only/` records the High stage of the Fixed experiment. It contains 14 evaluated snapshots and the iter-1 launch failure. `runs/ours/` contains 28 evaluated snapshots, including four failed evaluations.

| File or directory | Contents |
|---|---|
| `iteration_results.csv` | Combined evaluation sequence, stages, status, timing, and source/output links |
| `timing_samples.csv` | Five reference and five candidate values for each of 38 successful evaluations |
| `case_summary.csv` | Case endpoints and first-correctness times |
| `first_correct_events.csv`, `first_correct_summary.csv` | First-correctness event records and summary |
| `candidate_sources/`, `evaluation_outputs/` | Source and output excerpts for the first-correctness example |
| `runs/` | Candidate snapshots, evaluation outputs, iteration notes, and per-method data |
| `protocol.json` | Timing, correctness, and input parameters |

The timing protocol uses three warmups, five timed forwards, and median aggregation. Timing input seed 42 is separate from correctness seed bases 42, 43, and 50000. Each correctness base has ten trials at atol=rtol=0.001. Floating inputs use N(0,1).

High reaches first correctness at 4.127742 minutes. TileWeave first fails compilation at 3.076647 minutes and reaches correctness at 5.405595 minutes in iter-2. Both attempts are High-level and precede the first Lower at iter-5. These values round to the paper's 4.13 and 5.41 minutes.

High iter-10 passed numerical trials but was excluded after a missing ownership fence was identified. The final High implementation restores iter-9; TileWeave restores iter-26. The final case latencies are separate from the five-seed aggregate results in the main tables. Failed evaluations retain their status and have no successful timing samples.
