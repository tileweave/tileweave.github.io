# Case protocols

PDF Section 4.1 specifies three warmups, five timed executions, and median latency.

| Case | Timing samples per successful evaluation | Metric | Reference median |
|---|---|---|---:|
| MLP High stage and TileWeave | Five reference and five candidate samples | Ascend device-side forward elapsed interval | 4.63566 ms |
| MinGPT TileWeave, Figures 3–4 | Five reference and five candidate samples | HIP-event elapsed interval around complete forward | 44.953800201416016 ms |
| MinGPT comparison data, Figures 1 and 5 | Five reference and five candidate values per successful record | Paper comparison-data convention | 42.968631744384766 ms |

Each role has three warmups before its five timed forward calls. Timing input seed 42 is separate from correctness seed bases 42, 43, and 50000, with ten correctness trials each and atol=rtol=0.001. Activation inputs use N(0,1). Failed evaluations have no successful timing samples.

MLP includes 38 successful evaluations with 380 timing values. The MinGPT TileWeave trace includes 55 successful evaluations with 550 timing values. The MinGPT comparison data include 42 successful evaluations with 420 timing values. Five timing calls within an evaluation and five independent agent runs are separate dimensions.

The MLP first-correctness times round to 4.13 and 5.41 minutes. The MinGPT Figure 3 attention-call cost is a diagnostic quantity; full-forward latency determines candidate speedup. Figure 4's 23 printed numerical values are indexed in `../04_Rollback_traces/MinGPT_trace/FIG4_alignment.csv`.

Case parameters are recorded in `../03_MLP_first_correct_trace/protocol.json` and `../04_Rollback_traces/MinGPT_trace/run/protocol.json`. `CORRECTNESS_AND_TIMING.md` describes the platform timing boundaries and result aggregation.

The comparison data for Figures 1 and 5 are indexed in `../04_Rollback_traces/MinGPT_baselines/run_manifest.json`; the associated numerical records use the paper reporting values and coordinates.

The main-table reporting convention is best reported. The MinGPT search best (3.831 ms) and final verification (4.138 ms) remain distinct records; Figure 4 explicitly labels both. `ENDPOINT_DEFINITION.md` gives the selection rule and proposed manuscript clarification.
