# Low-only — paper evaluation table

Values use the paper reporting convention. Each evaluation links to its corresponding record and candidate directory.

| Evaluation | Elapsed min | Outcome | Candidate ms | Speedup | Best-so-far |
|---|---:|---|---:|---:|---:|
| [baseline](records/low_only/eval_01/output.txt) | 5.806395 | passed | 70.944855 | 0.605662x | 0.605662x |
| [iter-1](records/low_only/eval_02/output.txt) | 7.463961 | passed | 42.147137 | 1.019491x | 1.019491x |
| [iter-2](records/low_only/eval_03/output.txt) | 9.936918 | incomplete_no_verdict | — | — | 1.019491x |
| [iter-3](records/low_only/eval_04/output.txt) | 10.455247 | passed | 32.531590 | 1.320828x | 1.320828x |
| [iter-4](records/low_only/eval_05/output.txt) | 11.466514 | passed | 31.960571 | 1.344426x | 1.344426x |
| [iter-5](records/low_only/eval_06/output.txt) | 13.000588 | passed | 26.796909 | 1.603492x | 1.603492x |
| [iter-6](records/low_only/eval_07/output.txt) | 14.174023 | passed | 25.530140 | 1.683055x | 1.683055x |
| [iter-7](records/low_only/eval_08/output.txt) | 15.265286 | passed | 24.754332 | 1.735803x | 1.735803x |
| [iter-8](records/low_only/eval_09/output.txt) | 16.321457 | passed | 21.859386 | 1.965683x | 1.965683x |
| [iter-9](records/low_only/eval_10/output.txt) | 17.404776 | passed | 21.403768 | 2.007527x | 2.007527x |
| [iter-10](records/low_only/eval_11/output.txt) | 18.304349 | passed | 20.716604 | 2.074116x | 2.074116x |
| [iter-11](records/low_only/eval_12/output.txt) | 19.017114 | passed | 20.016467 | 2.146664x | 2.146664x |
| [iter-12](records/low_only/eval_13/output.txt) | 20.136054 | passed | 20.227074 | 2.124313x | 2.146664x |
| [iter-13](records/low_only/eval_14/output.txt) | 21.400381 | passed | 20.016467 | 2.146664x | 2.146664x |
| [iter-14](records/low_only/eval_15/output.txt) | 22.401155 | passed | 115.584312 | 0.371751x | 2.146664x |
| [final](records/low_only/eval_16/output.txt) | 23.687038 | passed | 20.016467 | 2.146664x | 2.146664x |
