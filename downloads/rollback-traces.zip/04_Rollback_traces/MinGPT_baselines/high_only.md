# High-only — paper evaluation table

Values use the paper reporting convention. Each evaluation links to its corresponding record and candidate directory.

This table covers the complete High-stage AKO invocation through its autonomous termination. See [High-only search and autonomous termination](HIGH_ONLY_NOTE.md) for the relationship to Fixed and the figure interpretation.

| Evaluation | Elapsed min | Outcome | Candidate ms | Speedup | Best-so-far |
|---|---:|---|---:|---:|---:|
| [baseline](records/high_only/eval_01/output.txt) | 1.432279 | failed | — | — | 0.000000x |
| [baseline](records/high_only/eval_02/output.txt) | 1.978706 | passed | 81.418663 | 0.527749x | 0.527749x |
| [iter-1](records/high_only/eval_03/output.txt) | 3.305101 | passed | 43.183468 | 0.995025x | 0.995025x |
| [iter-2](records/high_only/eval_04/output.txt) | 5.181053 | passed | 49.952297 | 0.860193x | 0.995025x |
| [iter-3](records/high_only/eval_05/output.txt) | 6.439306 | passed | 38.625977 | 1.112428x | 1.112428x |
| [iter-4](records/high_only/eval_06/output.txt) | 7.419637 | passed | 56.275871 | 0.763536x | 1.112428x |
| [iter-5](records/high_only/eval_07/output.txt) | 8.279406 | passed | 33.992752 | 1.264053x | 1.264053x |
| [iter-6](records/high_only/eval_08/output.txt) | 9.257163 | passed | 36.373936 | 1.181303x | 1.264053x |
| [iter-7](records/high_only/eval_09/output.txt) | 10.966824 | passed | 41.110313 | 1.045203x | 1.264053x |
| [iter-8](records/high_only/eval_10/output.txt) | 12.452499 | passed | 34.038261 | 1.262363x | 1.264053x |
| [iter-9](records/high_only/eval_11/output.txt) | 13.869567 | passed | 38.037716 | 1.129632x | 1.264053x |
| [final](records/high_only/eval_12/output.txt) | 14.721337 | passed | 34.133751 | 1.258831x | 1.264053x |
