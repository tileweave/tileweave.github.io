from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from native_runtime import Runtime
class ModelNew:
    def __init__(self, n_embd, n_head, attn_pdrop, resid_pdrop, max_seqlen):
        self.runtime = Runtime(Path(__file__).resolve().parent)
    def to(self, *args, **kwargs):
        return self
    def forward(self, *args):
        return self.runtime.forward(*args)
    __call__ = forward
