#include <hip/hip_runtime.h>
using h8 = _Float16 __attribute__((ext_vector_type(8)));
using f8 = float __attribute__((ext_vector_type(8)));
__device__ __forceinline__ f8 mma(h8 a,h8 b,f8 c) {
 return __builtin_amdgcn_wmma_f32_16x16x16_f16_w32_gfx12(a,b,c);
}
// Represent each FP32 operand by a half high part and a scaled residual.
// All four products are retained and accumulated in FP32.
template<int N> __global__ __launch_bounds__(128) void projection(const float* X,const float* W,const float* B,float* Y) {
 __shared__ _Float16 ah[32][32], al[32][32], bh[64][32], bl[64][32];
 int t=threadIdx.x, lane=t%32, wave=t/32;
 int mr=(wave/2)*16, nc=(wave%2)*32;
 f8 hh[2]={}, cross[2]={}, ll[2]={};
 for(int kb=0;kb<768;kb+=32) {
  __syncthreads();
  for(int i=t;i<32*32;i+=128) {
   int r=i/32,k=i%32; float v=X[(blockIdx.y*32+r)*768+kb+k];
   _Float16 h=(_Float16)v; ah[r][k]=h; al[r][k]=(_Float16)((v-(float)h)*4096.f);
  }
  for(int i=t;i<64*32;i+=128) {
   int r=i/32,k=i%32; float v=W[(blockIdx.x*64+r)*768+kb+k];
   _Float16 h=(_Float16)v; bh[r][k]=h; bl[r][k]=(_Float16)((v-(float)h)*4096.f);
  }
  __syncthreads();
  #pragma unroll
  for(int kk=0;kk<32;kk+=16) {
   h8 a,ar;
   #pragma unroll
   for(int e=0;e<8;e++){a[e]=ah[mr+lane%16][kk+lane/16*8+e];ar[e]=al[mr+lane%16][kk+lane/16*8+e];}
   #pragma unroll
   for(int j=0;j<2;j++) {
    h8 b,br;
    #pragma unroll
    for(int e=0;e<8;e++){b[e]=bh[nc+j*16+lane%16][kk+lane/16*8+e];br[e]=bl[nc+j*16+lane%16][kk+lane/16*8+e];}
    hh[j]=mma(a,b,hh[j]);cross[j]=mma(a,br,cross[j]);cross[j]=mma(ar,b,cross[j]);ll[j]=mma(ar,br,ll[j]);
   }
  }
 }
 #pragma unroll
 for(int j=0;j<2;j++) {
  int n=blockIdx.x*64+nc+j*16+lane%16;
  #pragma unroll
  for(int e=0;e<8;e++) {
   int m=blockIdx.y*32+mr+lane/16*8+e;
   Y[m*N+n]=(hh[j][e]+cross[j][e]*(1.f/4096.f)+ll[j][e]*(1.f/16777216.f))+B[n];
  }
 }
}
