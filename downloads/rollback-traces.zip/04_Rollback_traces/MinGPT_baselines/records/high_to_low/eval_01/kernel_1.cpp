#include <hip/hip_runtime.h>
#include <tl_templates/hip/gemm.h>
#include <tl_templates/hip/copy.h>
#include <tl_templates/hip/reduce.h>
#include <tl_templates/hip/scan.h>
#include <tl_templates/hip/ldsm.h>
#include <tl_templates/hip/threadblock_swizzle.h>
#include <tl_templates/hip/debug.h>

extern "C" __global__ void __launch_bounds__(128) main_kernel(float* __restrict__ Q, float* __restrict__ Y) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* q = ((void*)((char*)buf_dyn_shmem + 0));
  void* kv = ((void*)((char*)buf_dyn_shmem + 6144));
  void* p = ((void*)((char*)buf_dyn_shmem + 18560));
  float acc[12];
  float den[2];
  float mx[2];
  float score[4];
  float old[2];
  float mx_clear[2];
  float scale[2];
  float sm[2];
  #pragma unroll
  for (int i = 0; i < 12; ++i) {
    ((float*)q)[(((((i * 128) + ((int)threadIdx.x)) % 96) * 16) + (((i * 4) + (((int)threadIdx.x) >> 5)) / 3))] = Q[((((((((int)blockIdx.y) >> 3) * 1179648) + (((int)blockIdx.x) * 36864)) + ((((i * 4) + (((int)threadIdx.x) >> 5)) / 3) * 2304)) + ((((int)blockIdx.y) & 7) * 96)) + (((i * 128) + ((int)threadIdx.x)) % 96))];
  }
  #pragma unroll
  for (int i_1 = 0; i_1 < 3; ++i_1) {
    float broadcast_var = 0.000000e+00f;
    *(float4*)(acc + (i_1 * 4)) = make_float4(broadcast_var, broadcast_var, broadcast_var, broadcast_var);
  }
  float broadcast_var_1 = 0.000000e+00f;
  *(float2*)(den + 0) = make_float2(broadcast_var_1, broadcast_var_1);
  float broadcast_var_2 = -HUGE_VALF;
  *(float2*)(mx + 0) = make_float2(broadcast_var_2, broadcast_var_2);
  for (int block = 0; block < ((((int)blockIdx.x) >> 1) + 1); ++block) {
    __syncthreads();
    #pragma unroll
    for (int i_2 = 0; i_2 < 24; ++i_2) {
      ((float*)kv)[(((((i_2 * 4) + (((int)threadIdx.x) >> 5)) / 3) * 97) + (((i_2 * 128) + ((int)threadIdx.x)) % 96))] = Q[(((((((((int)blockIdx.y) >> 3) * 1179648) + (block * 73728)) + ((((i_2 * 4) + (((int)threadIdx.x) >> 5)) / 3) * 2304)) + ((((int)blockIdx.y) & 7) * 96)) + (((i_2 * 128) + ((int)threadIdx.x)) % 96)) + 768)];
    }
    float broadcast_var_3 = 0.000000e+00f;
    *(float4*)(score + 0) = make_float4(broadcast_var_3, broadcast_var_3, broadcast_var_3, broadcast_var_3);
    __syncthreads();
    #pragma unroll
    for (int k = 0; k < 96; ++k) {
      #pragma unroll
      for (int i_3 = 0; i_3 < 4; ++i_3) {
        score[i_3] = (score[i_3] + (((float*)q)[(((k * 16) + ((i_3 >> 1) * 8)) + (((int)threadIdx.x) >> 4))] * ((float*)kv)[((((i_3 & 1) * 1552) + ((((int)threadIdx.x) & 15) * 97)) + k)]));
      }
    }
    #pragma unroll
    for (int i_4 = 0; i_4 < 4; ++i_4) {
      float condval;
      if (((((block * 32) + ((i_4 & 1) * 16)) + (((int)threadIdx.x) & 15)) <= (((((int)blockIdx.x) * 16) + ((i_4 >> 1) * 8)) + (((int)threadIdx.x) >> 4)))) {
        condval = (score[i_4] * 1.020621e-01f);
      } else {
        condval = -HUGE_VALF;
      }
      score[i_4] = condval;
    }
    *(float2*)(old + 0) = *(float2*)(mx + 0);
    #pragma unroll
    for (int i_5 = 0; i_5 < 2; ++i_5) {
      mx_clear[i_5] = -HUGE_VALF;
      #pragma unroll
      for (int rv = 0; rv < 2; ++rv) {
        mx_clear[i_5] = max(mx_clear[i_5], score[((i_5 * 2) + rv)]);
      }
      mx_clear[i_5] = tl::AllReduce<tl::MaxOp, 16, 1, 0>::run(mx_clear[i_5]);
      mx[i_5] = max(mx[i_5], mx_clear[i_5]);
    }
    float2 __1;
    float2 __2;
      float2 v_ = *(float2*)(old + 0);
      float2 v__1 = *(float2*)(mx + 0);
      __2.x = (v_.x-v__1.x);
      __2.y = (v_.y-v__1.y);
    __1.x = __expf(__2.x);
    __1.y = __expf(__2.y);
    *(float2*)(scale + 0) = __1;
    #pragma unroll
    for (int i_6 = 0; i_6 < 2; ++i_6) {
      float2 __3;
      float2 __4;
        float2 v__2 = *(float2*)(score + (i_6 * 2));
        float2 v__3 = make_float2(mx[i_6], mx[i_6]);
        __4.x = (v__2.x-v__3.x);
        __4.y = (v__2.y-v__3.y);
      __3.x = __expf(__4.x);
      __3.y = __expf(__4.y);
      *(float2*)(score + (i_6 * 2)) = __3;
    }
    #pragma unroll
    for (int i_7 = 0; i_7 < 2; ++i_7) {
      sm[i_7] = 0.000000e+00f;
      #pragma unroll
      for (int rv_1 = 0; rv_1 < 2; ++rv_1) {
        sm[i_7] = (sm[i_7] + score[((i_7 * 2) + rv_1)]);
      }
      sm[i_7] = tl::AllReduce<tl::SumOp, 16, 1, 0>::run(sm[i_7]);
    }
    float2 __5;
      float2 __6;
        float2 v__4 = *(float2*)(den + 0);
        float2 v__5 = *(float2*)(scale + 0);
        __6.x = (v__4.x*v__5.x);
        __6.y = (v__4.y*v__5.y);
      float2 v__6 = *(float2*)(sm + 0);
      __5.x = (__6.x+v__6.x);
      __5.y = (__6.y+v__6.y);
    *(float2*)(den + 0) = __5;
    #pragma unroll
    for (int i_8 = 0; i_8 < 4; ++i_8) {
      ((float*)p)[(((((i_8 & 1) * 256) + ((((int)threadIdx.x) & 15) * 16)) + ((i_8 >> 1) * 8)) + (((int)threadIdx.x) >> 4))] = score[i_8];
    }
    __syncthreads();
    #pragma unroll
    for (int i_9 = 0; i_9 < 24; ++i_9) {
      ((float*)kv)[(((((i_9 * 4) + (((int)threadIdx.x) >> 5)) / 3) * 97) + (((i_9 * 128) + ((int)threadIdx.x)) % 96))] = Q[(((((((((int)blockIdx.y) >> 3) * 1179648) + (block * 73728)) + ((((i_9 * 4) + (((int)threadIdx.x) >> 5)) / 3) * 2304)) + ((((int)blockIdx.y) & 7) * 96)) + (((i_9 * 128) + ((int)threadIdx.x)) % 96)) + 1536)];
    }
    #pragma unroll
    for (int i_10 = 0; i_10 < 6; ++i_10) {
      float2 __7;
        float2 v__7 = *(float2*)(acc + (i_10 * 2));
        float2 v__8 = make_float2(scale[(i_10 / 3)], scale[(i_10 / 3)]);
        __7.x = (v__7.x*v__8.x);
        __7.y = (v__7.y*v__8.y);
      *(float2*)(acc + (i_10 * 2)) = __7;
    }
    __syncthreads();
    #pragma unroll
    for (int k_1 = 0; k_1 < 32; ++k_1) {
      #pragma unroll
      for (int i_11 = 0; i_11 < 12; ++i_11) {
        acc[i_11] = (acc[i_11] + (((float*)p)[(((k_1 * 16) + ((i_11 / 6) * 8)) + (((int)threadIdx.x) >> 4))] * ((float*)kv)[(((k_1 * 97) + ((i_11 % 6) * 16)) + (((int)threadIdx.x) & 15))]));
      }
    }
  }
  #pragma unroll
  for (int i_12 = 0; i_12 < 12; ++i_12) {
    Y[((((((((((int)blockIdx.y) >> 3) * 393216) + (((int)blockIdx.x) * 12288)) + ((i_12 / 6) * 6144)) + ((((int)threadIdx.x) >> 4) * 768)) + ((((int)blockIdx.y) & 7) * 96)) + ((i_12 % 6) * 16)) + (((int)threadIdx.x) & 15))] = (acc[i_12] / den[(i_12 / 6)]);
  }
}


#ifdef _WIN32
#define TL_EXPORT __declspec(dllexport)
#else
#define TL_EXPORT
#endif

#define ERROR_BUF_SIZE 1024
static char error_buf[ERROR_BUF_SIZE];

extern "C" TL_EXPORT const char* get_last_error() {
    return error_buf;
}

extern "C" TL_EXPORT int init() {
    error_buf[0] = '\0';
    
    int device_main_kernel = 0;
    hipError_t dev_res_main_kernel = hipGetDevice(&device_main_kernel);
    if (dev_res_main_kernel != hipSuccess) {
        snprintf(error_buf, ERROR_BUF_SIZE, "Failed to get HIP device for main_kernel: %s", hipGetErrorString(dev_res_main_kernel));
        return -1;
    }
    int max_smem_main_kernel = 0;
    hipError_t attr_res_main_kernel = hipDeviceGetAttribute(&max_smem_main_kernel, hipDeviceAttributeMaxSharedMemoryPerBlock, device_main_kernel);
    if (attr_res_main_kernel != hipSuccess || max_smem_main_kernel <= 0) {
        snprintf(error_buf, ERROR_BUF_SIZE, "Failed to query HIP max shared memory for main_kernel: %s", hipGetErrorString(attr_res_main_kernel));
        return -1;
    }
    if (20608 > max_smem_main_kernel) {
        snprintf(
            error_buf,
            ERROR_BUF_SIZE,
            "Requested dynamic shared memory %d exceeds device limit %d for main_kernel",
            20608,
            max_smem_main_kernel
        );
        return -1;
    }
    return 0;

    return 0;
}

extern "C" TL_EXPORT int call(float* __restrict__ Q, float* __restrict__ Y, hipStream_t stream=hipStreamDefault) {
	main_kernel<<<dim3(32, 1024, 1), dim3(128, 1, 1), 20608, stream>>>(Q, Y);
	TILELANG_CHECK_LAST_ERROR("main_kernel");

	return 0;
}
