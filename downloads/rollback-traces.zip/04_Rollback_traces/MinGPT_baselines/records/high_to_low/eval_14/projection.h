#include <hip/hip_runtime.h>
using h2 = _Float16 __attribute__((ext_vector_type(2)));
using h8 = _Float16 __attribute__((ext_vector_type(8)));
using f8 = float __attribute__((ext_vector_type(8)));
__device__ __forceinline__ f8 mma(h8 a,h8 b,f8 c) {
 return __builtin_amdgcn_wmma_f32_16x16x16_f16_w32_gfx12(a,b,c);
}
template<int N> __global__ __launch_bounds__(256) void projection(const float* X_,const float* W_,const float* B,float* Y) {
 const h2* X=(const h2*)X_;const h2* W=(const h2*)W_;
 __shared__ h2 a[64][65], b[128][65];
 int t=threadIdx.x,lane=t%32,wave=t/32;
 int mr=(wave/4)*32,nc=(wave%4)*32;
 f8 hh[2][2]={};
 h2 nextA[16],nextB[32];
 #pragma unroll
 for(int i=0;i<16;i++){int idx=t+i*256;nextA[i]=X[(blockIdx.y*64+idx/64)*768+idx%64];}
 #pragma unroll
 for(int i=0;i<32;i++){int idx=t+i*256;nextB[i]=W[(blockIdx.x*128+idx/64)*768+idx%64];}
 for(int kb=0;kb<768;kb+=64){
  __syncthreads();
  #pragma unroll
  for(int i=0;i<16;i++){int idx=t+i*256;a[idx/64][idx%64]=nextA[i];}
  #pragma unroll
  for(int i=0;i<32;i++){int idx=t+i*256;b[idx/64][idx%64]=nextB[i];}
  __syncthreads();
  if(kb+64<768){
   #pragma unroll
   for(int i=0;i<16;i++){int idx=t+i*256;nextA[i]=X[(blockIdx.y*64+idx/64)*768+kb+64+idx%64];}
   #pragma unroll
   for(int i=0;i<32;i++){int idx=t+i*256;nextB[i]=W[(blockIdx.x*128+idx/64)*768+kb+64+idx%64];}
  }
  #pragma unroll
  for(int kk=0;kk<64;kk+=16){
   h8 av[2],ar[2],bv[2],br[2];
   #pragma unroll
   for(int i=0;i<2;i++){
    #pragma unroll
    for(int e=0;e<8;e++){
     h2 va=a[mr+i*16+lane%16][kk+lane/16*8+e];av[i][e]=va[0];ar[i][e]=va[1];
     h2 vb=b[nc+i*16+lane%16][kk+lane/16*8+e];bv[i][e]=vb[0];br[i][e]=vb[1];
    }
   }
   #pragma unroll
   for(int i=0;i<2;i++){
    #pragma unroll
    for(int j=0;j<2;j++){
     hh[i][j]=mma(av[i],bv[j],hh[i][j]);hh[i][j]=mma(av[i],br[j],hh[i][j]);hh[i][j]=mma(ar[i],bv[j],hh[i][j]);hh[i][j]=mma(ar[i],br[j],hh[i][j]);
    }
   }
  }
 }
 #pragma unroll
 for(int i=0;i<2;i++){
  #pragma unroll
  for(int j=0;j<2;j++){
   int n=blockIdx.x*128+nc+j*16+lane%16;
   #pragma unroll
   for(int e=0;e<8;e++){int m=blockIdx.y*64+mr+i*16+lane/16*8+e;float v=hh[i][j][e]+B[n];if constexpr(N==2304){_Float16 h=(_Float16)v;((h2*)Y)[m*N+n]=h2{h,(_Float16)(v-(float)h)};}else{Y[m*N+n]=v;}}
  }
 }
}
