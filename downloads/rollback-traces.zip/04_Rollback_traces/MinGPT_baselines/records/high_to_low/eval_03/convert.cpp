#include <hip/hip_runtime.h>
using h2 = _Float16 __attribute__((ext_vector_type(2)));
__global__ void convert(const float* X,h2* Y,int n){
 int i=blockIdx.x*256+threadIdx.x;
 if(i<n){float v=X[i];_Float16 h=(_Float16)v;Y[i]=h2{h,(_Float16)((v-(float)h)*4096.f)};}
}
extern "C" int init(){return 0;}
extern "C" int call(float* X,float* Y,hipStream_t s){
 convert<<<dim3(CONVERT_SIZE/256),256,0,s>>>(X,(h2*)Y,CONVERT_SIZE);return hipGetLastError()!=hipSuccess;
}
