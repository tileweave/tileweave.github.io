#include <hip/hip_runtime.h>
using h2 = _Float16 __attribute__((ext_vector_type(2)));
using h8 = _Float16 __attribute__((ext_vector_type(8)));
using f8 = float __attribute__((ext_vector_type(8)));
__device__ __forceinline__ f8 mma(h8 a,h8 b,f8 c) {
 return __builtin_amdgcn_wmma_f32_16x16x16_f16_w32_gfx12(a,b,c);
}
template<int N> __global__ __launch_bounds__(128) void projection(const float* X_,const float* W_,const float* B,float* Y) {
 const h2* X=(const h2*)X_;const h2* W=(const h2*)W_;
 __shared__ h2 a[32][64], b[32][64];
 int t=threadIdx.x,lane=t%32,wave=t/32;
 int mr=(wave/2)*32,nc=(wave%2)*32;
 f8 hh[2][2]={},cross[2][2]={},ll[2][2]={};
 for(int kb=0;kb<768;kb+=32){
  __syncthreads();
  for(int i=t;i<64*32;i+=128){int r=i/32,k=i%32;a[k][r]=X[(blockIdx.y*64+r)*768+kb+k];b[k][r]=W[(blockIdx.x*64+r)*768+kb+k];}
  __syncthreads();
  #pragma unroll
  for(int kk=0;kk<32;kk+=16){
   h8 av[2],ar[2],bv[2],br[2];
   #pragma unroll
   for(int i=0;i<2;i++){
    #pragma unroll
    for(int e=0;e<8;e++){
     h2 va=a[kk+lane/16*8+e][mr+i*16+lane%16];av[i][e]=va[0];ar[i][e]=va[1];
     h2 vb=b[kk+lane/16*8+e][nc+i*16+lane%16];bv[i][e]=vb[0];br[i][e]=vb[1];
    }
   }
   #pragma unroll
   for(int i=0;i<2;i++){
    #pragma unroll
    for(int j=0;j<2;j++){
     hh[i][j]=mma(av[i],bv[j],hh[i][j]);cross[i][j]=mma(av[i],br[j],cross[i][j]);cross[i][j]=mma(ar[i],bv[j],cross[i][j]);ll[i][j]=mma(ar[i],br[j],ll[i][j]);
    }
   }
  }
 }
 #pragma unroll
 for(int i=0;i<2;i++){
  #pragma unroll
  for(int j=0;j<2;j++){
   int n=blockIdx.x*64+nc+j*16+lane%16;
   #pragma unroll
   for(int e=0;e<8;e++){int m=blockIdx.y*64+mr+i*16+lane/16*8+e;Y[m*N+n]=hh[i][j][e]+cross[i][j][e]/4096.f+ll[i][j][e]/16777216.f+B[n];}
  }
 }
}
