#include <hip/hip_runtime.h>
using h2 = _Float16 __attribute__((ext_vector_type(2)));
using h8 = _Float16 __attribute__((ext_vector_type(8)));
using f8 = float __attribute__((ext_vector_type(8)));
__device__ __forceinline__ f8 mma(h8 a,h8 b,f8 c) {
 return __builtin_amdgcn_wmma_f32_16x16x16_f16_w32_gfx12(a,b,c);
}
template<int N> __global__ __launch_bounds__(256) void projection(const float* X_,const float* W_,const float* B,float* Y) {
 const h2* X=(const h2*)X_;const h2* W=(const h2*)W_;
 __shared__ h2 a[128][33], b[64][33];
 int t=threadIdx.x,lane=t%32,wave=t/32;
 int mr=(wave/2)*32,nc=(wave%2)*32;
 f8 hh[2][2]={};
 for(int kb=0;kb<768;kb+=32){
  __syncthreads();
  for(int i=t;i<128*32;i+=256){int r=i/32,k=i%32;a[r][k]=X[(blockIdx.y*128+r)*768+kb+k];}
  for(int i=t;i<64*32;i+=256){int r=i/32,k=i%32;b[r][k]=W[(blockIdx.x*64+r)*768+kb+k];}
  __syncthreads();
  #pragma unroll
  for(int kk=0;kk<32;kk+=16){
   h8 av[2],ar[2],bv[2],br[2];
   #pragma unroll
   for(int i=0;i<2;i++){
    #pragma unroll
    for(int e=0;e<8;e++){
     h2 va=a[mr+i*16+lane%16][kk+lane/16*8+e];av[i][e]=va[0];ar[i][e]=va[1];
     h2 vb=b[nc+i*16+lane%16][kk+lane/16*8+e];bv[i][e]=vb[0];br[i][e]=vb[1];
    }
   }
   #pragma unroll
   for(int i=0;i<2;i++){
    #pragma unroll
    for(int j=0;j<2;j++){
     hh[i][j]=mma(av[i],bv[j],hh[i][j]);hh[i][j]=mma(av[i],br[j],hh[i][j]);hh[i][j]=mma(ar[i],bv[j],hh[i][j]);hh[i][j]=mma(ar[i],br[j],hh[i][j]);
    }
   }
  }
 }
 #pragma unroll
 for(int i=0;i<2;i++){
  #pragma unroll
  for(int j=0;j<2;j++){
   int n=blockIdx.x*64+nc+j*16+lane%16;
   #pragma unroll
   for(int e=0;e<8;e++){int m=blockIdx.y*128+mr+i*16+lane/16*8+e;float v=hh[i][j][e]+B[n];if constexpr(N==2304){_Float16 h=(_Float16)v;((h2*)Y)[m*N+n]=h2{h,(_Float16)(v-(float)h)};}else{Y[m*N+n]=v;}}
  }
 }
}
