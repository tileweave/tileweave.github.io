# MinGPT case trace

This case contains 59 numbered evaluations and final verification: 55 successful evaluations and five failures. Candidate snapshots, evaluation outputs and timing samples accompany the decision and Rollback records.

`iteration_results.csv` and `run/iteration_index.csv` link each evaluation to its source and output. `run/timing_samples.csv` contains 550 values: five reference and five candidate samples for each successful evaluation. Timing uses three warmups followed by five timed forwards at input seed 42, with median aggregation. Correctness seed bases 42, 43 and 50000 are a separate dimension.

## Figure 4: candidate history

| Evaluation | Candidate latency | Reference latency | Speedup |
|---|---|---|---|
| Best candidate, iter-53 | 3.831209897994995 ms | 44.953800201416016 ms | 11.73357800754845x |
| Final verification | 4.137706756591797 ms | 44.953800201416016 ms | 10.864423905778228x |

Figure 4 presents the individual candidate history in a schematic layout. Its selected-source and final-verification annotations describe separate evaluations. `FIG4_alignment.csv` links all 23 printed numeric labels to the records.

## Figure 5: best-so-far progress

`figure5_curve.csv` contains 55 correct evaluations plus initial zero and a termination hold. Plot `best_so_far_speedup` against `elapsed_min` with post-step interpolation.

Figure 5 uses the comparison reference of **42.968631744384766 ms**, giving a best-so-far endpoint of **11.215420947537158x** for the same iter-53 candidate. The later final verification does not lower the cumulative maximum. Use each figure's specified reference; see `../FIGURE_DATA.md` and `../../00_paper_protocol/ENDPOINT_DEFINITION.md`.

## Diagnosis and Rollback records

`run/decision_record/` contains agent events, readable output, iteration notes, an evaluation index and four diagnosis reports. `rollback_paths.csv` identifies the two code-reuse paths. `FIG3_diagnostic.md` links the iter-8 attention-call diagnosis and associated source.
