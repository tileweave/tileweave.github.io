# Figure 3 diagnosis

The iter-8 whole-attention-call latency is **2.786430 ms**, matching Figure 3 on PDF page 6. It covers the entire attention call; it is separate from the complete MinGPT forward latency and the reduction operation shown in the source excerpt.

- High source: `run/sessions/1/opt/attention/high8/ModelNew.py`.
- Candidate snapshot: `run/sessions/1/trajectory/20260926_100232_iter-8/`.
- Diagnostic report: `run/decision_record/diagnostics/iter-8.txt`.

The report links the High call site, native implementation, tensor bindings, call-group costs, and available hardware counters.
