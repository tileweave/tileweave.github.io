#include <hip/hip_runtime.h>
#include <tl_templates/hip/gemm.h>
#include <tl_templates/hip/copy.h>
#include <tl_templates/hip/reduce.h>
#include <tl_templates/hip/scan.h>
#include <tl_templates/hip/ldsm.h>
#include <tl_templates/hip/threadblock_swizzle.h>
#include <tl_templates/hip/debug.h>

extern "C" __global__ void __launch_bounds__(256) main_kernel(float* __restrict__ X, half_t* __restrict__ Y) {
  {
    float _local_cast_1[4];
    half_t _local_cast[4];
    *(float4*)(_local_cast_1 + 0) = *(float4*)(X + ((((int)blockIdx.x) * 1024) + (((int)threadIdx.x) * 4)));
    uint2 __1;
    float4 v_ = *(float4*)(_local_cast_1 + 0);
    *((half_t*)(&(((half2*)(&(__1.x)))->x))) = (half_t)(v_.x);
    *((half_t*)(&(((half2*)(&(__1.x)))->y))) = (half_t)(v_.y);
    *((half_t*)(&(((half2*)(&(__1.y)))->x))) = (half_t)(v_.z);
    *((half_t*)(&(((half2*)(&(__1.y)))->y))) = (half_t)(v_.w);
    *(uint2*)(_local_cast + 0) = __1;
    *(uint2*)(Y + ((((int)blockIdx.x) * 1024) + (((int)threadIdx.x) * 4))) = *(uint2*)(_local_cast + 0);
  }
}


#ifdef _WIN32
#define TL_EXPORT __declspec(dllexport)
#else
#define TL_EXPORT
#endif

#define ERROR_BUF_SIZE 1024
static char error_buf[ERROR_BUF_SIZE];

extern "C" TL_EXPORT const char* get_last_error() {
    return error_buf;
}

extern "C" TL_EXPORT int init() {
    error_buf[0] = '\0';
    
    return 0;
}

extern "C" TL_EXPORT int call(float* __restrict__ X, half_t* __restrict__ Y, hipStream_t stream=hipStreamDefault) {
	main_kernel<<<dim3(49152, 1, 1), dim3(256, 1, 1), 0, stream>>>(X, Y);
	TILELANG_CHECK_LAST_ERROR("main_kernel");

	return 0;
}
