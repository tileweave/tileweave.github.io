#include <hip/hip_runtime.h>
#include <tl_templates/hip/gemm.h>
#include <tl_templates/hip/copy.h>
#include <tl_templates/hip/reduce.h>
#include <tl_templates/hip/scan.h>
#include <tl_templates/hip/ldsm.h>
#include <tl_templates/hip/threadblock_swizzle.h>
#include <tl_templates/hip/debug.h>

extern "C" __global__ void __launch_bounds__(256) main_kernel(half_t* __restrict__ Q, half_t* __restrict__ Y) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* p = ((void*)((char*)buf_dyn_shmem + 0));
  void* k = ((void*)((char*)buf_dyn_shmem + 0));
  void* v = ((void*)((char*)buf_dyn_shmem + 16384));
  void* q = ((void*)((char*)buf_dyn_shmem + 22528));
  void* workspace = ((void*)((char*)buf_dyn_shmem + 0));
  void* workspace_1 = ((void*)((char*)buf_dyn_shmem + 0));
  float m[8];
  float l[8];
  float o[24];
  float s[32];
  float old[8];
  float m_clear[8];
  float alpha[8];
  float rows[8];
  #pragma unroll
  for (int i = 0; i < 2; ++i) {
    float broadcast_var = -HUGE_VALF;
    *(float4*)(m + (i * 4)) = make_float4(broadcast_var, broadcast_var, broadcast_var, broadcast_var);
  }
  #pragma unroll
  for (int i_1 = 0; i_1 < 2; ++i_1) {
    float broadcast_var_1 = 0.000000e+00f;
    *(float4*)(l + (i_1 * 4)) = make_float4(broadcast_var_1, broadcast_var_1, broadcast_var_1, broadcast_var_1);
  }
  #pragma unroll
  for (int i_2 = 0; i_2 < 6; ++i_2) {
    float broadcast_var_2 = 0.000000e+00f;
    *(float4*)(o + (i_2 * 4)) = make_float4(broadcast_var_2, broadcast_var_2, broadcast_var_2, broadcast_var_2);
  }
  for (int nb = 0; nb < ((((int)blockIdx.x) >> 1) + 1); ++nb) {
    #pragma unroll
    for (int i_3 = 0; i_3 < 8; ++i_3) {
      float broadcast_var_3 = 0.000000e+00f;
      *(float4*)(s + (i_3 * 4)) = make_float4(broadcast_var_3, broadcast_var_3, broadcast_var_3, broadcast_var_3);
    }
    for (int d = 0; d < 3; ++d) {
      __syncthreads();
      *(uint4*)(((half_t*)q) + ((((((int)threadIdx.x) >> 2) * 32) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))) = *(uint4*)(Q + (((((((((int)blockIdx.y) >> 3) * 1179648) + (((int)blockIdx.x) * 147456)) + ((((int)threadIdx.x) >> 2) * 2304)) + ((((int)blockIdx.y) & 7) * 96)) + (d * 32)) + ((((int)threadIdx.x) & 3) * 8)));
      #pragma unroll
      for (int i_4 = 0; i_4 < 2; ++i_4) {
        *(uint4*)(((half_t*)k) + ((((i_4 * 2048) + ((((int)threadIdx.x) >> 2) * 32)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))) = *(uint4*)(Q + (((((((((((int)blockIdx.y) >> 3) * 1179648) + (nb * 294912)) + (i_4 * 147456)) + ((((int)threadIdx.x) >> 2) * 2304)) + ((((int)blockIdx.y) & 7) * 96)) + (d * 32)) + ((((int)threadIdx.x) & 3) * 8)) + 768));
      }
      {
        half_t A_local[8];
        half_t B_local[32];
        __syncthreads();
        for (int ki = 0; ki < 2; ++ki) {
          *(uint4*)(A_local + 0) = *(uint4*)(((half_t*)q) + ((((((((int)threadIdx.x) & 127) >> 5) * 512) + ((((int)threadIdx.x) & 15) * 32)) + (((((((int)threadIdx.x) & 7) >> 2) + ki) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 8)));
          for (int j = 0; j < 4; ++j) {
            *(uint4*)(B_local + (j * 8)) = *(uint4*)(((half_t*)k) + ((((((((int)threadIdx.x) >> 7) * 2048) + (j * 512)) + ((((int)threadIdx.x) & 15) * 32)) + (((((((int)threadIdx.x) & 7) >> 2) + ki) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 8)));
          }
          for (int j_1 = 0; j_1 < 4; ++j_1) {
            {
      typedef __attribute__((__vector_size__(8 * sizeof(__fp16)))) __fp16 tl_v8f16;
      typedef __attribute__((__vector_size__(8 * sizeof(float)))) float tl_v8f32;
      *((tl_v8f32*)s + j_1) = __builtin_amdgcn_wmma_f32_16x16x16_f16_w32_gfx12(
          *((tl_v8f16*)A_local + 0),
          *((tl_v8f16*)B_local + j_1),
          *((tl_v8f32*)s + j_1));
    };
          }
        }
      }
    }
    #pragma unroll
    for (int i_5 = 0; i_5 < 32; ++i_5) {
      float condval;
      if ((((((nb * 128) + ((((int)threadIdx.x) >> 7) * 64)) + ((i_5 >> 3) * 16)) + (((int)threadIdx.x) & 15)) <= (((((int)blockIdx.x) * 64) + (((((int)threadIdx.x) & 127) >> 4) * 8)) + (i_5 & 7)))) {
        condval = (s[i_5] * 1.020621e-01f);
      } else {
        condval = -HUGE_VALF;
      }
      s[i_5] = condval;
    }
    #pragma unroll
    for (int i_6 = 0; i_6 < 2; ++i_6) {
      *(float4*)(old + (i_6 * 4)) = *(float4*)(m + (i_6 * 4));
    }
    #pragma unroll
    for (int r=0;r<8;++r) {
      m_clear[r]=-HUGE_VALF;
      #pragma unroll
      for (int c=0;c<4;++c) m_clear[r]=max(m_clear[r],s[c*8+r]);
    }
    tl::AllReduce<tl::MaxOp,256,128,0,8,256>::run_batch(m_clear,(float*)workspace);
    tl::AllReduce<tl::MaxOp,16,1,0,8,256>::run_batch(m_clear);
    #pragma unroll
    for (int r=0;r<8;++r) m[r]=max(m[r],m_clear[r]);
    #pragma unroll
    for (int i_8 = 0; i_8 < 2; ++i_8) {
      float4 __1;
      float4 __2;
        float4 v_ = *(float4*)(old + (i_8 * 4));
        float4 v__1 = *(float4*)(m + (i_8 * 4));
        __2.x = (v_.x-v__1.x);
        __2.y = (v_.y-v__1.y);
        __2.z = (v_.z-v__1.z);
        __2.w = (v_.w-v__1.w);
      __1.x = __expf(__2.x);
      __1.y = __expf(__2.y);
      __1.z = __expf(__2.z);
      __1.w = __expf(__2.w);
      *(float4*)(alpha + (i_8 * 4)) = __1;
    }
    #pragma unroll
    for (int i_9 = 0; i_9 < 8; ++i_9) {
      float4 __3;
      float4 __4;
        float4 v__2 = *(float4*)(s + (i_9 * 4));
        float4 v__3 = *(float4*)(m + ((i_9 & 1) * 4));
        __4.x = (v__2.x-v__3.x);
        __4.y = (v__2.y-v__3.y);
        __4.z = (v__2.z-v__3.z);
        __4.w = (v__2.w-v__3.w);
      __3.x = __expf(__4.x);
      __3.y = __expf(__4.y);
      __3.z = __expf(__4.z);
      __3.w = __expf(__4.w);
      *(float4*)(s + (i_9 * 4)) = __3;
    }
    #pragma unroll
    for (int r=0;r<8;++r) {
      rows[r]=0.0f;
      #pragma unroll
      for (int c=0;c<4;++c) rows[r]+=s[c*8+r];
    }
    tl::AllReduce<tl::SumOp,256,128,0,8,256>::run_batch(rows,(float*)workspace);
    tl::AllReduce<tl::SumOp,16,1,0,8,256>::run_batch(rows);
    #pragma unroll
    for (int i_11 = 0; i_11 < 2; ++i_11) {
      float4 __5;
        float4 __6;
          float4 v__4 = *(float4*)(l + (i_11 * 4));
          float4 v__5 = *(float4*)(alpha + (i_11 * 4));
          __6.x = (v__4.x*v__5.x);
          __6.y = (v__4.y*v__5.y);
          __6.z = (v__4.z*v__5.z);
          __6.w = (v__4.w*v__5.w);
        float4 v__6 = *(float4*)(rows + (i_11 * 4));
        __5.x = (__6.x+v__6.x);
        __5.y = (__6.y+v__6.y);
        __5.z = (__6.z+v__6.z);
        __5.w = (__6.w+v__6.w);
      *(float4*)(l + (i_11 * 4)) = __5;
    }
    #pragma unroll
    for (int i_12 = 0; i_12 < 6; ++i_12) {
      float4 __7;
        float4 v__7 = *(float4*)(o + (i_12 * 4));
        float4 v__8 = *(float4*)(alpha + ((i_12 & 1) * 4));
        __7.x = (v__7.x*v__8.x);
        __7.y = (v__7.y*v__8.y);
        __7.z = (v__7.z*v__8.z);
        __7.w = (v__7.w*v__8.w);
      *(float4*)(o + (i_12 * 4)) = __7;
    }
    __syncthreads();
    #pragma unroll
    for (int i_13 = 0; i_13 < 32; ++i_13) {
      ((half_t*)p)[(((((((((int)threadIdx.x) & 127) >> 4) * 1024) + ((i_13 & 7) * 128)) + ((((int)threadIdx.x) >> 7) * 64)) + ((i_13 >> 3) * 16)) + (((int)threadIdx.x) & 15))] = ((half_t)s[i_13]);
    }
    for (int vb = 0; vb < 4; ++vb) {
      __syncthreads();
      *(uint4*)(((half_t*)q) + ((((((int)threadIdx.x) >> 2) * 32) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))) = *(uint4*)(((half_t*)p) + ((((((int)threadIdx.x) >> 2) * 128) + (vb * 32)) + ((((int)threadIdx.x) & 3) * 8)));
      #pragma unroll
      for (int i_14 = 0; i_14 < 3; ++i_14) {
        *(uint2*)(((half_t*)v) + ((((((((i_14 * 32) + (((int)threadIdx.x) >> 3)) % 3) * 1024) + ((((i_14 * 32) + (((int)threadIdx.x) >> 3)) / 3) * 32)) + (((((((i_14 * 8) + (((int)threadIdx.x) >> 5)) % 6) / 3) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 16)) + (((((((i_14 * 16) + (((int)threadIdx.x) >> 4)) % 6) / 3) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 8)) + ((((int)threadIdx.x) & 1) * 4))) = *(uint2*)(Q + ((((((((((int)blockIdx.y) >> 3) * 1179648) + (nb * 294912)) + (vb * 73728)) + ((((i_14 * 32) + (((int)threadIdx.x) >> 3)) / 3) * 2304)) + ((((int)blockIdx.y) & 7) * 96)) + ((((i_14 * 256) + ((int)threadIdx.x)) % 24) * 4)) + 1536));
      }
      {
        half_t A_local_1[8];
        half_t B_local_1[24];
        __syncthreads();
        for (int ki_1 = 0; ki_1 < 2; ++ki_1) {
          *(uint4*)(A_local_1 + 0) = *(uint4*)(((half_t*)q) + ((((((((int)threadIdx.x) & 127) >> 5) * 512) + ((((int)threadIdx.x) & 15) * 32)) + (((((((int)threadIdx.x) & 7) >> 2) + ki_1) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 8)));
          for (int j_2 = 0; j_2 < 3; ++j_2) {
            for (int local_id = 0; local_id < 8; ++local_id) {
              B_local_1[((j_2 * 8) + local_id)] = ((half_t*)v)[(((((((((((((int)threadIdx.x) >> 7) * 3) + j_2) >> 1) * 1024) + (ki_1 * 512)) + (((((int)threadIdx.x) & 31) >> 4) * 256)) + (local_id * 32)) + ((((local_id >> 2) + ((((((int)threadIdx.x) >> 7) * 3) + j_2) & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + ((local_id & 3) >> 1)) & 1) * 8)) + (((int)threadIdx.x) & 7))];
            }
          }
          for (int j_3 = 0; j_3 < 3; ++j_3) {
            {
      typedef __attribute__((__vector_size__(8 * sizeof(__fp16)))) __fp16 tl_v8f16;
      typedef __attribute__((__vector_size__(8 * sizeof(float)))) float tl_v8f32;
      *((tl_v8f32*)o + j_3) = __builtin_amdgcn_wmma_f32_16x16x16_f16_w32_gfx12(
          *((tl_v8f16*)A_local_1 + 0),
          *((tl_v8f16*)B_local_1 + j_3),
          *((tl_v8f32*)o + j_3));
    };
          }
        }
      }
    }
  }
  #pragma unroll
  for (int i_15 = 0; i_15 < 24; ++i_15) {
    Y[(((((((((((int)blockIdx.y) >> 3) * 393216) + (((int)blockIdx.x) * 49152)) + (((((int)threadIdx.x) & 127) >> 4) * 6144)) + ((i_15 & 7) * 768)) + ((((int)blockIdx.y) & 7) * 96)) + ((((int)threadIdx.x) >> 7) * 48)) + ((i_15 >> 3) * 16)) + (((int)threadIdx.x) & 15))] = ((half_t)(o[i_15] / l[(i_15 & 7)]));
  }
}


#ifdef _WIN32
#define TL_EXPORT __declspec(dllexport)
#else
#define TL_EXPORT
#endif

#define ERROR_BUF_SIZE 1024
static char error_buf[ERROR_BUF_SIZE];

extern "C" TL_EXPORT const char* get_last_error() {
    return error_buf;
}

extern "C" TL_EXPORT int init() {
    error_buf[0] = '\0';
    
    int device_main_kernel = 0;
    hipError_t dev_res_main_kernel = hipGetDevice(&device_main_kernel);
    if (dev_res_main_kernel != hipSuccess) {
        snprintf(error_buf, ERROR_BUF_SIZE, "Failed to get HIP device for main_kernel: %s", hipGetErrorString(dev_res_main_kernel));
        return -1;
    }
    int max_smem_main_kernel = 0;
    hipError_t attr_res_main_kernel = hipDeviceGetAttribute(&max_smem_main_kernel, hipDeviceAttributeMaxSharedMemoryPerBlock, device_main_kernel);
    if (attr_res_main_kernel != hipSuccess || max_smem_main_kernel <= 0) {
        snprintf(error_buf, ERROR_BUF_SIZE, "Failed to query HIP max shared memory for main_kernel: %s", hipGetErrorString(attr_res_main_kernel));
        return -1;
    }
    if (26624 > max_smem_main_kernel) {
        snprintf(
            error_buf,
            ERROR_BUF_SIZE,
            "Requested dynamic shared memory %d exceeds device limit %d for main_kernel",
            26624,
            max_smem_main_kernel
        );
        return -1;
    }
    return 0;

    return 0;
}

extern "C" TL_EXPORT int call(half_t* __restrict__ Q, half_t* __restrict__ Y, hipStream_t stream=hipStreamDefault) {
	main_kernel<<<dim3(8, 1024, 1), dim3(256, 1, 1), 26624, stream>>>(Q, Y);
	TILELANG_CHECK_LAST_ERROR("main_kernel");

	return 0;
}
