#!/bin/bash
set -o pipefail
cd "$(dirname "$0")/.."
LABEL="${1:-manual}"
[[ "$LABEL" =~ ^[a-zA-Z0-9_-]+$ ]] || exit 2
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
TRAJ_DIR="trajectory/${TIMESTAMP}_${LABEL}"
mkdir -p "$TRAJ_DIR"
/home/xiaoxinyu/venvs/dsl-native-opt/bin/python -c 'import json,sys;from pathlib import Path;sys.path.insert(0,'"'"'scripts'"'"');from rocm_diagnose import context;Path(sys.argv[1]).write_text(json.dumps(context(Path.cwd()),indent=2))' "$TRAJ_DIR/evaluation-context.json" || exit $?
timeout --signal=TERM --kill-after=30s 1800 /home/xiaoxinyu/venvs/dsl-native-opt/bin/python scripts/rocm_bench.py --ref reference.py --solution solution/ModelNew.py --backend auto 2>&1 | tee _bench_output.txt
STATUS=${PIPESTATUS[0]}
cp -r solution/* "$TRAJ_DIR/" 2>/dev/null || true
cp _bench_output.txt "$TRAJ_DIR/output.txt"
rm -f _bench_output.txt
exit "$STATUS"
