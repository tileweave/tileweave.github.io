from pathlib import Path
import re
p=Path('solution/kernel_2.cpp');s=p.read_text()
ks=s.index('  for (int k = 0; k < ')
nk=int(re.search(r'k < (\d+)',s[ks:]).group(1))
a=s.index('    #pragma unroll\n    for (int i_1',ks)
brace=s.index('{',a);depth=1;b=brace+1
while depth:
    if s[b]=='{':depth+=1
    elif s[b]=='}':depth-=1
    b+=1
old=s[a:b]
na=int(re.search(r'i_1 < (\d+)',old).group(1))
bk=int(re.search(r'\(k \* (\d+)\)',old).group(1))
store=next(l for l in old.splitlines() if '*(uint2*)(((half_t*)a)' in l)
lhs,rhs=store.strip().split(' = ',1)
pref=old.replace(store,'      pre_a[i_1] = '+rhs)
init=pref.replace(f'(k * {bk})','0')
next_pref=pref.replace(f'(k * {bk})',f'((k+1) * {bk})')
stage=f'    #pragma unroll\n    for(int i_1=0;i_1<{na};++i_1) {lhs} = pre_a[i_1];'
s=s[:a]+stage+s[b:]
s=s[:ks]+f'  uint2 pre_a[{na}];\n'+init+'\n'+s[ks:]
anchor=s.index('      __syncthreads();',s.index('half_t B_local['))
anchor+=len('      __syncthreads();')
s=s[:anchor]+f'\n      if(k+1<{nk}) {{\n'+next_pref+'\n      }'+s[anchor:]
p.write_text(s)
