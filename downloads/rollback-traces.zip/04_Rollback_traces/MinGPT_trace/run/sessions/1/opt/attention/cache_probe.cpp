#include <hip/hip_runtime.h>
typedef float v4f __attribute__((ext_vector_type(4)));
extern "C" __global__ void probe(const v4f* x, v4f* y) {
  v4f a=__builtin_nontemporal_load(x+threadIdx.x);
  __builtin_nontemporal_store(a,y+threadIdx.x);
}
