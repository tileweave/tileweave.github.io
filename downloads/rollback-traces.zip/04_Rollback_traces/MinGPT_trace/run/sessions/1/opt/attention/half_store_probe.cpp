#include <hip/hip_runtime.h>
#include <hip/hip_fp16.h>
extern "C" __global__ void probe(const float* x, __half* y) {
  __half a=__float2half(x[threadIdx.x]);
  __builtin_nontemporal_store(__builtin_bit_cast(unsigned short,a),(unsigned short*)(y+threadIdx.x));
}
