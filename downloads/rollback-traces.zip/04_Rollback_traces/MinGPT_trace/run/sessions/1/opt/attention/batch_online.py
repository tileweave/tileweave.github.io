from pathlib import Path
p=Path('solution/kernel_4.cpp');s=p.read_text()
a=s.index('    #pragma unroll\n    for (int i_7') if 'for (int i_7 = 0; i_7 < 8;' in s else -1
# Identify max reduction by m_clear initialization, finding enclosing loop.
start=s.index('      m_clear[')
a=s.rfind('    #pragma unroll',0,start)
b=s.index('    #pragma unroll',s.index('      m[',start))
# b is next top-level pragma following closing max loop.
s=s[:a]+'''    #pragma unroll
    for (int r=0;r<8;++r) {
      m_clear[r]=-HUGE_VALF;
      #pragma unroll
      for (int c=0;c<2;++c) m_clear[r]=max(m_clear[r],s[c*8+r]);
    }
    tl::AllReduce<tl::MaxOp,256,128,0,8,256>::run_batch(m_clear,(float*)workspace);
    tl::AllReduce<tl::MaxOp,16,1,0,8,256>::run_batch(m_clear);
    #pragma unroll
    for (int r=0;r<8;++r) m[r]=max(m[r],m_clear[r]);
'''+s[b:]
start=s.index('      rows[')
a=s.rfind('    #pragma unroll',0,start)
# end at next loop after final AllReduce row
end=s.index('      rows[',s.index('tl::AllReduce<tl::SumOp',start))
b=s.index('    #pragma unroll',end)
s=s[:a]+'''    #pragma unroll
    for (int r=0;r<8;++r) {
      rows[r]=0.0f;
      #pragma unroll
      for (int c=0;c<2;++c) rows[r]+=s[c*8+r];
    }
    tl::AllReduce<tl::SumOp,256,128,0,8,256>::run_batch(rows,(float*)workspace);
    tl::AllReduce<tl::SumOp,16,1,0,8,256>::run_batch(rows);
'''+s[b:]
s=s.replace('buf_dyn_shmem + 36864','buf_dyn_shmem + 12288').replace('buf_dyn_shmem + 45056','buf_dyn_shmem + 12288').replace('buf_dyn_shmem + 46080','buf_dyn_shmem + 12288').replace('47104','36864')
p.write_text(s)
