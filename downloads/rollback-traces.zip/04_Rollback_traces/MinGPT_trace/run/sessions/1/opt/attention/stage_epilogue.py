from pathlib import Path
import sys
mode=sys.argv[1]
if mode=='wide':
    file='kernel_2.cpp';bn=256;rows=64;dtype='half_t';vec='uint4';vw=8;outn=2304;oldsm=24576
elif mode=='narrow':
    file='kernel_2.cpp';bn=128;rows=128;dtype='half_t';vec='uint4';vw=8;outn=2304;oldsm=32768
elif mode=='projection':
    file='kernel_4.cpp';bn=128;rows=64;dtype='float';vec='float4';vw=4;outn=768;oldsm=32768
else: raise ValueError(mode)
p=Path('solution')/file;s=p.read_text();nc=bn//2
assert f'float c[{nc}]' in s
start=s.index('  #pragma unroll\n  for (int i_5 = 0;')
end=s.index('\n}\n\n\n#ifdef',start)
condition='true' if rows==128 else '((threadIdx.x&127)>>6)==stage'
code=f'''  // Operand buffers are dead; reuse LDS for coalesced output writes.
  {dtype}* epilogue=({dtype}*)buf_dyn_shmem;
  #pragma unroll
  for(int stage=0;stage<{128//rows};++stage) {{
    __syncthreads();
    if({condition}) {{
      #pragma unroll
      for(int e=0;e<{nc};++e) {{
        int row=((threadIdx.x&127)>>5)*32+(e/{nc//2})*16+((threadIdx.x&31)>>4)*8+(e&7)-stage*{rows};
        int col=(threadIdx.x>>7)*{nc}+((e%{nc//2})>>3)*16+(threadIdx.x&15);
        epilogue[row*{bn}+(col^((row&7)*{vw})^((row&8)*2))]=({dtype})(c[e]+B[blockIdx.y*{bn}+col]);
      }}
    }}
    __syncthreads();
    #pragma unroll
    for(int t=0;t<{rows*bn//256//vw};++t) {{
      int idx=t*256+threadIdx.x;
      int row=idx/{bn//vw}, col=(idx%{bn//vw})*{vw};
      *({vec}*)(Y+(blockIdx.x*128+stage*{rows}+row)*{outn}+blockIdx.y*{bn}+col)=*({vec}*)(epilogue+row*{bn}+(col^((row&7)*{vw})^((row&8)*2)));
    }}
  }}
'''
s=s[:start]+code+s[end:]
if oldsm!=32768:
    s=s.replace(f'if ({oldsm} >','if (32768 >').replace(f'\n            {oldsm},','\n            32768,').replace(f' {oldsm}, stream',' 32768, stream')
p.write_text(s)
