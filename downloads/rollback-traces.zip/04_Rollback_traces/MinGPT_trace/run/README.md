# MinGPT run records

`iteration_index.csv` indexes all 60 evaluations. Candidate source snapshots and outputs are in `sessions/1/trajectory/`. `timing_samples.csv` supplies five values per successful role. `protocol.json` records the timing and correctness parameters.

`decision_record/agent-events.jsonl` contains the ordered agent events; `agent-output.txt` is the readable transcript. `decision_index.csv` links evaluations to transcript events and candidate snapshots. Iteration notes record source selection, retained branches, edits, and stopping decisions. Diagnostic reports accompany iter-2, iter-8, iter-43, and iter-49.

`launch.json` records launch settings; `state.json` records completion. `evaluation_events.jsonl` indexes evaluation outputs. `deployment/` and `sessions/1/scripts/` retain the workflow and execution source used by the case.
