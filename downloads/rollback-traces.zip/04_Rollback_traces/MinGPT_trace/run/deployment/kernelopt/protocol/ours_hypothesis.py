"""Stable hypothesis records and conservative follow-up attribution.

This module records what the routing model proposed, then associates later
checkpoint facts without treating chronological adjacency as causality.  It is
pure: it does not inspect source files, execute candidates, or call a model.
"""
from __future__ import annotations

from copy import deepcopy
import json
import math


VERSION = "tileweave-hypothesis-v1"
JUDGMENTS = {"supported", "refuted"}
SCOPE_FIELDS = ("level", "visit", "ancestry", "reference_text")
# These are the only untyped, pre-catalogue spellings that identify the
# checkpoint's whole-program benchmark median.  Natural-language predictions
# are deliberately excluded: words such as "stage" or "launch" need a typed
# measurement identity before they can become causal receipt evidence.
LEGACY_WHOLE_PROGRAM_ALIASES = frozenset({
    "candidate_median_ms",
    "latency",
    "median_latency",
})


def _json_copy(value):
    """Return a detached JSON value and reject opaque runtime objects."""
    return json.loads(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False))


def _fingerprint(value):
    payload = json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return (payload.encode()).decode("utf-8", errors="surrogateescape")


def _text(value):
    value = value.strip() if isinstance(value, str) else ""
    return value or None


def _finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def _scope(context):
    task = context.get("task_contract") or {}
    return {
        "level": context.get("level"),
        "visit": context.get("visit"),
        "ancestry": context.get("ancestry"),
        "reference_text": task.get("reference_text", context.get("reference_text")),
    }


def _mapped_controls(finding):
    controls = []
    for item in finding.get("controls") or []:
        if not isinstance(item, dict):
            continue
        args = item.get("args") or {}
        controls.append({
            "level": item.get("level"),
            "name": item.get("name"),
            "object_id": args.get("object_id"),
        })
    return sorted(controls, key=lambda item: (
        str(item.get("level")), str(item.get("name")), str(item.get("object_id"))))


def hypothesis_record(action, finding, context, proposal=None):
    """Bind one model hypothesis to evidence, a control, and branch scope.

    ``action.stop_if`` is an optimizer stopping condition.  It is deliberately
    stored separately and never reused as a falsifier.  A falsifier exists only
    when the raw proposal explicitly supplies ``disconfirm_if`` (the shared
    wire field), or one of the older explicit aliases ``falsifier`` and
    ``falsification_condition``.
    """
    proposal = proposal or {}
    checkpoint = finding.get("checkpoint")
    if not checkpoint or checkpoint != context.get("checkpoint"):
        raise ValueError("Hypothesis must be bound to the current checkpoint")
    if not _text(action.get("edit_op")):
        raise ValueError("Hypothesis needs a bound corrective control")
    args = action.get("args") or {}
    if not _text(args.get("object_id")):
        raise ValueError("Hypothesis needs a bound source object")

    evidence_ids = sorted({item.get("id") for item in finding.get("evidence") or []
                           if isinstance(item, dict) and _text(item.get("id"))})
    if not evidence_ids:
        raise ValueError("Hypothesis needs bound evidence IDs")
    proposed_evidence = proposal.get("evidence_ids")
    if proposed_evidence is not None and sorted(set(proposed_evidence)) != evidence_ids:
        raise ValueError("Proposal evidence does not match the bound finding")

    statement = _text(proposal.get("hypothesis"))
    if statement is None:
        statement = _text((finding.get("action") or {}).get("rationale"))
    if statement is None:
        raise ValueError("Hypothesis statement is missing")
    expected_metric = _text(action.get("expected_metric"))
    if expected_metric is None:
        raise ValueError("Hypothesis needs a predicted metric")

    disconfirm_if = None
    for name in ("disconfirm_if", "falsifier", "falsification_condition"):
        disconfirm_if = _text(proposal.get(name))
        if disconfirm_if is not None:
            break
    control = {
        "name": action["edit_op"],
        "cause_class": (finding.get("cause") or {}).get("class"),
        "object_id": args["object_id"],
        "target_levels": sorted(set(action.get("target_levels") or [])),
        "mapped_controls": _mapped_controls(finding),
    }
    identity = {
        "checkpoint": checkpoint,
        "scope": _scope(context),
        "evidence_ids": evidence_ids,
        "control": control,
        "hypothesis": statement,
        "prediction": {
            "expected_metric": expected_metric,
            "statement": _text(proposal.get("prediction")),
        },
        "disconfirm_if": disconfirm_if,
    }
    decision_at = context.get("decision_at")
    boundary_known = _finite(decision_at)
    source_created_at = context.get("created_at")
    return _json_copy({
        "version": VERSION,
        "id": "hyp-" + _fingerprint(identity)[:24],
        **identity,
        # decision_at is the only sound lower bound for later effects.  Older
        # manifests only expose the source checkpoint time; retain it for
        # replay, while making the uncertainty explicit and non-promotable.
        "created_at": decision_at if boundary_known else source_created_at,
        "source_created_at": source_created_at,
        "decision_boundary": {
            "status": "known" if boundary_known else "unknown",
            "decision_at": decision_at if boundary_known else None,
        },
        "finding_id": action.get("finding_id"),
        "route": action.get("route"),
        "alternative_actions": _text(proposal.get("alternative_actions")),
        "stop_condition": _text(action.get("stop_if")),
        "status": "not_tested",
        "model_judgment": False,
        "interpretation": (
            "A proposed mechanism bound to its original evidence and branch. "
            "Later timing alone cannot support or refute it."
        ),
    })


def _same_scope(checkpoint, scope):
    # Missing ancestry is ambiguity, not a wildcard over branches.
    if any(scope.get(field) is None for field in SCOPE_FIELDS):
        return False
    return all(checkpoint.get(field) == scope[field] for field in SCOPE_FIELDS)


def _measurement_status(checkpoint):
    metrics = checkpoint.get("metrics") or {}
    compiled, correct = metrics.get("compiled"), metrics.get("correctness")
    latency = metrics.get("candidate_median_ms")
    if compiled is False:
        return "compile_failed"
    if compiled is True and correct is False:
        return "correctness_failed"
    if compiled is True and correct is True and _finite(latency) and latency > 0:
        return "measured"
    return "incomplete"


def _cost_facts(checkpoint, effects):
    keys = ("wall_seconds", "evaluation_seconds", "eval_seconds", "cost", "costs",
            "tokens", "resource_cost")
    facts = {key: deepcopy(checkpoint[key]) for key in keys if key in checkpoint}
    effect_costs = []
    for effect in effects:
        values = {key: deepcopy(effect[key]) for key in keys if key in effect}
        if values:
            effect_costs.append(values)
    if effect_costs:
        facts["edit_effect_costs"] = effect_costs
    return facts


def _control_matches(receipt, hypothesis):
    control = receipt.get("control")
    expected = hypothesis["control"]
    if not isinstance(control, dict):
        return False
    name = control.get("name", control.get("edit_op"))
    if name != expected.get("name") or control.get("object_id") != expected.get("object_id"):
        return False
    if "target_levels" in control:
        return sorted(set(control["target_levels"] or [])) == expected.get("target_levels", [])
    return True


def _checkpoint_metric_binding(checkpoint, metric_name):
    """Resolve one legacy metric name without interpreting model prose.

    A future typed measurement catalogue can extend this at the sidecar layer.
    Until then, only the exact whole-program aliases above are sound: a profile
    metric also needs launch/window identity that a bare string cannot carry.
    Value and unit are returned together so a unit cannot be guessed for an
    otherwise unresolved value.
    """
    requested = _text(metric_name)
    normalized = requested.lower() if requested is not None else None
    if normalized not in LEGACY_WHOLE_PROGRAM_ALIASES:
        return {
            "status": "legacy_untyped",
            "reason": "expected_metric_is_not_an_exact_whole_program_alias",
            "requested_metric": requested,
            "metric": None,
            "scope": None,
            "value": None,
            "unit": None,
        }
    return {
        "status": "legacy_exact_alias",
        "reason": None,
        "requested_metric": requested,
        "metric": "candidate_median_ms",
        "scope": "whole_program",
        "value": (checkpoint.get("metrics") or {}).get("candidate_median_ms"),
        "unit": "ms",
    }


def _actual_source_change(effects, before, after):
    exact = [effect for effect in effects
             if effect.get("before") == before.get("digest")
             and effect.get("after") == after.get("digest")]
    changed = any(
        bool(_text(effect.get("source_diff")))
        or (bool(effect.get("changed_files"))
            and before.get("source_files") is not None
            and after.get("source_files") is not None
            and before.get("source_files") != after.get("source_files"))
        for effect in exact)
    return exact, changed


def assessment_receipts(assessments, hypotheses, checkpoints, edit_effects):
    """Turn same-call model assessments into controller-bound receipts.

    The model supplies only a hypothesis ID, source pair, implementation state,
    judgment, rationale, and a description of which observed edit tests the
    premise.  Control, falsifier, correctness, measurements, and source-change
    facts are copied from controller-owned records.  Invalid references are
    returned as auditable receipts with ``validation_errors``; they never gain
    a promotable ``model_assessment``.
    """
    known = {item.get("id"): _json_copy(item) for item in hypotheses
             if isinstance(item, dict) and item.get("id")}
    checkpoint_by_digest = {item.get("digest"): deepcopy(item) for item in checkpoints
                            if isinstance(item, dict) and item.get("digest")}
    effects = [deepcopy(item) for item in edit_effects if isinstance(item, dict)]
    receipts = []
    for index, raw in enumerate(assessments or []):
        assessment = deepcopy(raw) if isinstance(raw, dict) else {}
        hypothesis = known.get(assessment.get("hypothesis_id"))
        before = checkpoint_by_digest.get(assessment.get("before"))
        after = checkpoint_by_digest.get(assessment.get("after"))
        errors = []
        if hypothesis is None:
            errors.append("unknown_hypothesis_id")
        if before is None:
            errors.append("unknown_before_checkpoint")
        if after is None:
            errors.append("unknown_after_checkpoint")

        exact_effects, source_changed = ([], False)
        if hypothesis is not None and before is not None and after is not None:
            scope = hypothesis.get("scope") or {}
            if not _same_scope(before, scope) or not _same_scope(after, scope):
                errors.append("source_scope")
            boundary = hypothesis.get("created_at")
            if (not _finite(boundary) or not _finite(after.get("created_at"))
                    or after["created_at"] <= boundary
                    or (hypothesis.get("decision_boundary") or {}).get("status") != "known"):
                errors.append("decision_boundary")
            exact_effects, source_changed = _actual_source_change(effects, before, after)
            if not exact_effects:
                errors.append("edit_effect")
            if not source_changed:
                errors.append("source_change")

        implementation = assessment.get("implementation_status")
        if implementation not in {"executed", "not_implemented", "unknown"}:
            errors.append("implementation_status")
            implementation = "unknown"
        judgment = assessment.get("judgment")
        if judgment not in {"supported", "refuted", "inconclusive", "not_tested"}:
            errors.append("judgment")
        rationale = _text(assessment.get("rationale"))
        test_evidence = _text(assessment.get("test_evidence"))
        if rationale is None:
            errors.append("rationale")
        if implementation == "executed" and test_evidence is None:
            errors.append("test_evidence")
        if implementation != "executed" and judgment in JUDGMENTS:
            errors.append("judgment_without_execution")

        receipt = {
            "version": VERSION,
            "hypothesis_id": assessment.get("hypothesis_id"),
            "before": assessment.get("before"),
            "after": assessment.get("after"),
            "execution_status": implementation,
            "reported_judgment": judgment,
            "reported_rationale": rationale,
            "test_evidence": test_evidence,
            "validation_errors": errors,
            "source_effect_count": len(exact_effects),
            "source_changed": source_changed,
        }
        if hypothesis is not None:
            receipt["control"] = deepcopy(hypothesis.get("control"))
            receipt["disconfirm_if"] = hypothesis.get("disconfirm_if")
            if not hypothesis.get("disconfirm_if"):
                errors.append("falsifier")
        if before is not None and after is not None and hypothesis is not None:
            before_metrics, after_metrics = before.get("metrics") or {}, after.get("metrics") or {}
            receipt["full_correctness"] = {
                "complete": all(isinstance(value, bool) for value in (
                    before_metrics.get("compiled"), before_metrics.get("correctness"),
                    after_metrics.get("compiled"), after_metrics.get("correctness"))),
                "before_compiled": before_metrics.get("compiled"),
                "after_compiled": after_metrics.get("compiled"),
                "before_passed": before_metrics.get("correctness"),
                "after_passed": after_metrics.get("correctness"),
            }
            metric_name = hypothesis.get("prediction", {}).get("expected_metric")
            before_binding = _checkpoint_metric_binding(before, metric_name)
            after_binding = _checkpoint_metric_binding(after, metric_name)
            before_value, after_value = before_binding["value"], after_binding["value"]
            before_unit, after_unit = before_binding["unit"], after_binding["unit"]
            binding_status = (before_binding["status"]
                              if before_binding["status"] == after_binding["status"]
                              else "incompatible")
            receipt["metric_evidence"] = {
                "complete": (_finite(before_value) and _finite(after_value)
                             and bool(before_unit) and before_unit == after_unit
                             and binding_status == "legacy_exact_alias"),
                "metric": metric_name,
                "resolved_metric": (before_binding["metric"]
                                    if before_binding["metric"] == after_binding["metric"] else None),
                "scope": (before_binding["scope"]
                          if before_binding["scope"] == after_binding["scope"] else None),
                "binding_status": binding_status,
                "binding_reason": (before_binding["reason"]
                                   if before_binding["reason"] == after_binding["reason"] else None),
                "unit": before_unit if before_unit == after_unit else None,
                "before": before_value,
                "after": after_value,
            }
            correctness = receipt["full_correctness"]
            if (correctness["complete"] is not True
                    or correctness["before_compiled"] is not True
                    or correctness["after_compiled"] is not True
                    or correctness["before_passed"] is not True
                    or correctness["after_passed"] is not True):
                errors.append("full_correctness")
            if receipt["metric_evidence"]["complete"] is not True:
                errors.append("metric_evidence")
            if binding_status == "legacy_untyped":
                errors.append("legacy_untyped_metric")
        can_judge = (not errors and implementation == "executed" and judgment in JUDGMENTS
                     and rationale is not None and test_evidence is not None)
        if can_judge:
            receipt["model_assessment"] = {
                "judgment": judgment,
                "rationale": rationale,
                "test_evidence": test_evidence,
            }
        receipt["id"] = "assessment-" + _fingerprint({
            "index": index, "assessment": assessment,
            "bound_hypothesis": hypothesis.get("id") if hypothesis else None,
        })[:24]
        receipts.append(_json_copy(receipt))
    return receipts


def _validate_receipt(receipt, hypothesis, before, after, effects):
    """Validate the explicit causal-judgment receipt contract.

    A promotable receipt has exact hypothesis/source/control binding, a matching
    edit-effect record, full before/after correctness, complete metric evidence,
    and a model assessment with both a judgment and rationale.
    """
    errors = []
    if receipt.get("hypothesis_id") != hypothesis.get("id"):
        errors.append("hypothesis_id")
    if (hypothesis.get("decision_boundary") or {}).get("status") != "known":
        errors.append("decision_boundary")
    if receipt.get("before") != before.get("digest") or receipt.get("after") != after.get("digest"):
        errors.append("source_pair")
    if not _control_matches(receipt, hypothesis):
        errors.append("control")
    if not any(effect.get("before") == before.get("digest")
               and effect.get("after") == after.get("digest") for effect in effects):
        errors.append("edit_effect")
    _, source_changed = _actual_source_change(effects, before, after)
    if not source_changed:
        errors.append("source_change")

    for error in receipt.get("validation_errors") or []:
        errors.append("assessment:" + str(error))

    receipt_falsifier = _text(receipt.get("disconfirm_if", receipt.get("falsifier")))
    if not hypothesis.get("disconfirm_if") or receipt_falsifier != hypothesis.get("disconfirm_if"):
        errors.append("falsifier")

    correctness = receipt.get("full_correctness")
    before_metrics, after_metrics = before.get("metrics") or {}, after.get("metrics") or {}
    before_correct, after_correct = before_metrics.get("correctness"), after_metrics.get("correctness")
    if (not isinstance(correctness, dict) or correctness.get("complete") is not True
            or correctness.get("before_passed") is not True
            or correctness.get("after_passed") is not True
            or before_metrics.get("compiled") is not True or after_metrics.get("compiled") is not True
            or before_correct is not True or after_correct is not True):
        errors.append("full_correctness")

    metric = receipt.get("metric_evidence")
    expected_name = hypothesis.get("prediction", {}).get("expected_metric")
    before_binding = _checkpoint_metric_binding(before, expected_name)
    after_binding = _checkpoint_metric_binding(after, expected_name)
    if (not isinstance(metric, dict) or metric.get("complete") is not True
            or _text(metric.get("metric")) != expected_name
            or not _text(metric.get("unit"))
            or not _finite(metric.get("before")) or not _finite(metric.get("after"))):
        errors.append("metric_evidence")
    elif (before_binding["status"] != "legacy_exact_alias"
          or after_binding["status"] != "legacy_exact_alias"):
        errors.append("legacy_untyped_metric")
    elif (before_binding["value"] != metric.get("before")
          or after_binding["value"] != metric.get("after")
          or before_binding["unit"] != metric.get("unit")
          or after_binding["unit"] != metric.get("unit")):
        errors.append("metric_checkpoint_mismatch")

    assessment = receipt.get("model_assessment")
    if (not isinstance(assessment, dict)
            or assessment.get("judgment") not in JUDGMENTS
            or not _text(assessment.get("rationale"))
            or not _text(assessment.get("test_evidence"))):
        errors.append("model_assessment")
    return errors


def followup_records(hypothesis, checkpoints, edit_effects, receipts=()):
    """Associate later same-branch facts without inferring mechanism success.

    The returned list contains one record per later checkpoint with an explicit
    benchmark result.  An exact source diff is still only a temporal follow-up:
    without an optimizer/model receipt its status is ``inconclusive`` and its
    execution status is unknown.  ``not_tested`` is reserved for an explicit
    rejection/non-implementation receipt (or the hypothesis before any
    follow-up exists).  Only a fully validated receipt can produce
    ``supported`` or ``refuted`` and ``model_judgment=True``.
    """
    hypothesis = _json_copy(hypothesis)
    scope = hypothesis.get("scope") or {}
    started = hypothesis.get("created_at")
    if not _finite(started) or any(scope.get(field) is None for field in SCOPE_FIELDS):
        return []

    ordered = sorted((deepcopy(cp) for cp in checkpoints if isinstance(cp, dict)),
                     key=lambda cp: (cp.get("created_at", float("inf")), str(cp.get("digest"))))
    by_digest = {cp.get("digest"): cp for cp in ordered if cp.get("digest")}
    effects = [deepcopy(effect) for effect in edit_effects if isinstance(effect, dict)]
    receipt_list = [deepcopy(receipt) for receipt in receipts if isinstance(receipt, dict)]
    records = []
    for checkpoint in ordered:
        created = checkpoint.get("created_at")
        if (not _finite(created) or created <= started or not _same_scope(checkpoint, scope)):
            continue
        measurement_status = _measurement_status(checkpoint)
        if measurement_status == "incomplete":
            continue
        digest = checkpoint.get("digest")
        linked_effects = [effect for effect in effects if effect.get("after") == digest]
        source_pairs = sorted({(effect.get("before"), effect.get("after"))
                               for effect in linked_effects if effect.get("before")})
        fact = {
            "hypothesis_id": hypothesis["id"],
            "checkpoint": digest,
            "commit": checkpoint.get("commit"),
            "created_at": created,
            "scope": {field: checkpoint.get(field) for field in SCOPE_FIELDS},
            "measurement_status": measurement_status,
            "metrics": deepcopy(checkpoint.get("metrics") or {}),
            "source_pairs": [list(pair) for pair in source_pairs],
            "edit_effects": linked_effects,
            "cost_facts": _cost_facts(checkpoint, linked_effects),
            "status": "inconclusive",
            "execution_status": "unknown",
            "model_judgment": False,
            "receipt_validation_errors": [],
            "interpretation": (
                "A later same-branch measured commit with unknown intervention status; temporal "
                "association and a source diff do not show that the proposed mechanism was tested."
            ),
        }

        candidates = [receipt for receipt in receipt_list
                      if receipt.get("hypothesis_id") == hypothesis["id"]
                      and receipt.get("after") == digest]
        valid = []
        rejected = []
        explicitly_not_tested = False
        for receipt in candidates:
            if receipt.get("execution_status") in {"rejected", "not_implemented", "not_tested"}:
                explicitly_not_tested = True
            before = by_digest.get(receipt.get("before"))
            if before is None or not _same_scope(before, scope):
                errors = ["source_before_scope"]
            else:
                errors = _validate_receipt(receipt, hypothesis, before, checkpoint, linked_effects)
            if errors:
                rejected.append({"receipt_id": receipt.get("id"), "errors": errors})
            else:
                valid.append(receipt)
        judgments = {(receipt["model_assessment"]["judgment"],
                      receipt["model_assessment"]["rationale"]) for receipt in valid}
        if len(judgments) == 1:
            judgment, rationale = next(iter(judgments))
            fact.update(status=judgment, model_judgment=True,
                        model_assessment={"judgment": judgment, "rationale": rationale},
                        interpretation=(
                            "Explicit model judgment with exact hypothesis, source, control, "
                            "correctness, metric, and edit-effect binding."
                        ))
            fact["execution_status"] = "tested"
        elif explicitly_not_tested and not valid:
            fact["status"] = "not_tested"
            fact["execution_status"] = "not_implemented"
            fact["receipt_validation_errors"] = rejected
            fact["interpretation"] = (
                "An explicit receipt says the proposed intervention was rejected or not implemented."
            )
        elif candidates:
            fact["status"] = "inconclusive"
            if len(judgments) > 1:
                rejected.append({"receipt_id": None, "errors": ["conflicting_model_assessments"]})
            fact["receipt_validation_errors"] = rejected
            fact["interpretation"] = (
                "A receipt referred to this follow-up, but its causal binding was incomplete or conflicting."
            )
        fact["id"] = "followup-" + _fingerprint({
            "hypothesis_id": hypothesis["id"], "checkpoint": digest,
            "source_pairs": fact["source_pairs"],
        })[:24]
        records.append(_json_copy(fact))
    return records
