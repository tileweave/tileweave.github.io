"""Bookkeeping for the one optimizer conversation; no agent runner."""
import shutil
import subprocess
import json
import math
from pathlib import Path


def handoff_candidates(root, visit, level):
    """Select only this visit's controller-recorded, fully validated sources."""
    root = Path(root)
    choices = {}
    for record in sorted((root / 'checkpoints').glob('*/checkpoint.json')):
        cp = json.loads(record.read_text())
        metrics = cp.get('metrics', {})
        ms = metrics.get('candidate_median_ms')
        if (cp.get('level') != level or cp.get('visit') != visit
                or metrics.get('correctness') is not True or metrics.get('validated_suite') is not True
                or not isinstance(ms, (int, float)) or not math.isfinite(ms) or ms <= 0
                or (record.parent / 'protocol-invalid.json').exists()):
            continue
        if Path(cp['path']).resolve() != record.parent.resolve():
            raise ValueError('Handoff checkpoint path is outside its recorded directory')
        if not (record.parent / 'solution/ModelNew.py').is_file():
            continue
        choices[record.parent.name] = cp
    return choices


def select_handoff(root, visit, level, selection='best'):
    choices = handoff_candidates(root, visit, level)
    if not choices:
        raise ValueError(f'No fully validated {level} checkpoint is available for handoff')
    if selection == 'best':
        return min(choices.values(), key=lambda cp: cp['metrics']['candidate_median_ms'])
    if selection not in choices:
        raise ValueError(f'Select a fully validated {level} checkpoint from this visit')
    return choices[selection]


def high_handoff_candidates(root, visit):
    return handoff_candidates(root, visit, 'High')


def select_high_handoff(root, visit, selection='best'):
    return select_handoff(root, visit, 'High', selection)


def native_coverage(current, high, transitions):
    """Old descendants cannot establish a changed High program's Low headroom."""
    source = current if current["level"] == "High" else high
    matching = [edge for edge in transitions if source and edge.get("from") == "High"
                and edge.get("to") == "Native" and edge.get("status") == "accepted"
                and edge.get("source") == source["digest"]]
    return dict(current_high_entered_native=bool(matching), headroom="unknown",
                interpretation=("A visit is not proof of exhausted headroom. Low results from a different "
                                "High source are historical only. You decide whether a new visit is worthwhile."))

def carry_iteration_log(source, target, level):
    """Move the run's own account of what it has tried into the new workspace.

    Without this a switch starts from a blank log: the optimizer renumbers
    from iter 1 and has no record that the level it just left exists, let
    alone what each of its candidates did. AKO's scaffold rule already says
    not to overwrite an ITERATIONS.md that is already present, so carrying it
    forward needs no change on the skill's side -- only that the file be
    there before the optimizer looks for it.

    The retained entries are this one optimizer's own history within one run.
    No sibling arm's work and no earlier run's work ever appears here.
    """
    log = Path(source) / "ITERATIONS.md"
    if not log.is_file():
        return None
    destination = Path(target) / "ITERATIONS.md"
    destination.write_text(
        log.read_text(errors="replace").rstrip()
        + f"\n\n---\n\n# Continued in {level}\n\n"
        "Everything above was measured in the level this run just left. Those entries stay\n"
        "valid as a record of what was tried and what it cost; their runtimes were measured\n"
        "on that representation, not this one. Keep numbering iterations onward from the\n"
        "last entry above rather than restarting at 1.\n")
    return destination


def copy_session(source, target):
    """Move this run's one private conversation along with the editable workspace."""
    if source == target:
        return
    import agent_driver
    history = source / agent_driver.PRIVATE
    if history.exists():
        shutil.copytree(history, target / agent_driver.PRIVATE, dirs_exist_ok=True)
    if (source / ".git").is_dir():
        # Preserve actual source/log history once per switch, not as feedback text.
        subprocess.run(["git", "-C", str(source), "branch", "-f", "history/visit-" + source.name, "HEAD"], check=True)
        if (target / '.git').is_dir():
            # Git object files are read-only. Let Git import its own history
            # rather than overwrite an existing branch's object database.
            subprocess.run(['git', '-C', str(target), 'fetch', '--quiet', '--no-tags', str(source),
                            'HEAD', '+refs/heads/*:refs/remotes/handoff/*'], check=True)
            subprocess.run(['git', '-C', str(target), 'reset', '--mixed', 'FETCH_HEAD'],
                           check=True, stdout=subprocess.DEVNULL)
        else:
            shutil.copytree(source / ".git", target / ".git")
