#!/usr/bin/env python3
"""Run a frozen Fixed/Ours/Native-only comparison sequentially on one GPU."""

from __future__ import annotations

import argparse
import csv
import fcntl
import io
import json
import os
from pathlib import Path
import re
import subprocess
import time


ROOT = Path(os.environ.get("KERNELBENCH_REPO", "/data1/xiaoxinyu/dsl-native-opt-live"))
MODES = ("fixed", "ours", "native-only")
FOUR_MODES = (*MODES, "high-only")
TERMINAL = {"complete", "incomplete", "failed", "aborted", "exhausted"}


def digest(path: Path) -> str:
    return (path.read_bytes()).decode("utf-8", errors="surrogateescape")


def write_json(path: Path, value: dict) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")
    temporary.replace(path)


def read_manifest(path: Path) -> dict:
    manifest = json.loads(path.read_text())
    schema = manifest.get("schema_version")
    if schema not in {"cuda-comparison-v1", "cuda-comparison-four-arm-v1"}:
        raise ValueError("unknown comparison manifest")
    modes = FOUR_MODES if schema == "cuda-comparison-four-arm-v1" else MODES
    if [item.get("mode") for item in manifest.get("arms", [])] != list(modes):
        raise ValueError("comparison arm order must be fixed before measurement")
    if not re.fullmatch(r"cuda:\d+", manifest.get("device", "")):
        raise ValueError("comparison requires an explicit CUDA device")
    if not re.fullmatch(r"level\d+/[A-Za-z0-9_.-]+", manifest.get("task", "")):
        raise ValueError("invalid KernelBench task")
    for arm in manifest["arms"]:
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]*", arm.get("run_id", "")):
            raise ValueError("invalid run id")
    if len({arm["run_id"] for arm in manifest["arms"]}) != len(modes):
        raise ValueError("comparison run ids must be unique")
    for relative, expected in manifest.get("deployed_files", {}).items():
        path = Path(relative)
        if path.is_absolute() or ".." in path.parts or not re.fullmatch(r"[0-9a-f]{64}", expected):
            raise ValueError("invalid deployed file digest")
    return manifest


def verify_snapshot(manifest: dict) -> None:
    source = ROOT / "thirdparty/KernelBench/KernelBench" / (manifest["task"] + ".py")
    if not source.is_file() or digest(source) != manifest["reference_text"]:
        raise RuntimeError("reference changed since comparison submission")
    for relative, expected in manifest["deployed_files"].items():
        target = ROOT / relative
        if target.is_symlink() or not target.is_file() or digest(target) != expected:
            raise RuntimeError(f"controller/evaluator changed since comparison submission: {relative}")


def state_path(arm: dict) -> Path:
    return ROOT / "runs" / arm["run_id"] / "state.json"


def queued_state(manifest: dict, arm: dict) -> dict:
    native = arm["mode"] == "native-only"
    return dict(run_id=arm["run_id"], comparison_id=manifest["comparison_id"],
                task=manifest["task"], mode=arm["mode"], status="queued",
                phase="queued", stage="Low" if native else "High",
                backend="cuda" if native else "tilelang", device=manifest["device"],
                agent_model=manifest["model"], high_iterations=0, low_iterations=0,
                elapsed_seconds=0, current={}, best={}, queued_at_epoch=manifest["created_at_epoch"])


def hardware_snapshot(device: str) -> dict:
    """Read compute users of the selected physical GPU, without touching them."""
    index = device.split(":", 1)[1]
    gpu_query = subprocess.run(
        ["nvidia-smi", "--query-gpu=index,uuid,name,memory.used,utilization.gpu", "--format=csv,noheader,nounits"],
        capture_output=True, text=True, check=True, timeout=15)
    app_query = subprocess.run(
        ["nvidia-smi", "--query-compute-apps=gpu_uuid,pid,used_memory", "--format=csv,noheader,nounits"],
        capture_output=True, text=True, check=True, timeout=15)
    gpu = next((row for row in csv.reader(io.StringIO(gpu_query.stdout))
                if len(row) >= 5 and row[0].strip() == index), None)
    if gpu is None:
        raise RuntimeError(f"physical GPU {device} is not visible to nvidia-smi")
    uuid = gpu[1].strip()
    apps = [dict(gpu_uuid=row[0].strip(), pid=row[1].strip(), used_memory_mb=row[2].strip())
            for row in csv.reader(io.StringIO(app_query.stdout))
            if len(row) >= 3 and row[0].strip() == uuid and row[1].strip().isdigit()]
    return {"observed_at": time.time(), "device": device,
            "gpu": dict(index=index, uuid=uuid, name=gpu[2].strip(),
                        memory_used_mb=gpu[3].strip(), utilization_percent=gpu[4].strip()),
            "compute_processes": apps}


def wait_for_gpu(device: str, progress: Path, arm: dict) -> dict:
    while True:
        try:
            hardware = hardware_snapshot(device)
            reason = (f"compute processes on {device}: "
                      + ", ".join(item["pid"] for item in hardware["compute_processes"]))
            if not hardware["compute_processes"]:
                return hardware
        except (OSError, RuntimeError, subprocess.SubprocessError) as error:
            hardware, reason = None, f"GPU occupancy probe failed: {error}"
        write_json(progress, {"status": "waiting_for_gpu", "run_id": arm["run_id"],
                              "mode": arm["mode"], "reason": reason, "hardware": hardware,
                              "retry_seconds": 30, "at": time.time()})
        time.sleep(30)


def prepare(manifest: dict) -> None:
    verify_snapshot(manifest)
    for arm in manifest["arms"]:
        if state_path(arm).parent.exists():
            raise FileExistsError(f"comparison run already exists: {arm['run_id']}")
    for arm in manifest["arms"]:
        state_path(arm).parent.mkdir(parents=True)
        write_json(state_path(arm), queued_state(manifest, arm))


def timing_preflight(manifest: dict, directory: Path, env: dict) -> None:
    command = [manifest["python"], str(ROOT / "thirdparty/KernelBench/scripts/ncu_smoke.py")]
    result = subprocess.run(command, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                            capture_output=True, text=True, timeout=180)
    (directory / "timing-preflight.txt").write_text(result.stdout + result.stderr)
    if result.returncode:
        raise RuntimeError("NCU timing preflight failed; see timing-preflight.txt")
    # Library startup chatter may precede the JSON report.
    start = result.stdout.find('{\n  "status"')
    record = json.loads(result.stdout[start:]) if start >= 0 else {}
    if record.get("status") != "pass" or record.get("kernel_counts") != [2, 2, 2]:
        raise RuntimeError("NCU preflight did not validate all six expected launches")


def run(manifest: dict, manifest_path: Path) -> int:
    lock_path = manifest_path.parent / "queue.lock"
    with lock_path.open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        progress = manifest_path.parent / "progress.json"
        preflight_done = False
        for arm in manifest["arms"]:
            state_file = state_path(arm)
            state = json.loads(state_file.read_text())
            if state.get("status") != "queued":
                raise ValueError(f"queue expected an untouched queued arm: {arm['run_id']}")
            try:
                verify_snapshot(manifest)
            except Exception as error:
                for pending in manifest["arms"]:
                    pending_state_path = state_path(pending)
                    pending_state = json.loads(pending_state_path.read_text())
                    if pending_state.get("status") == "queued":
                        pending_state.update(status="incomplete", phase="snapshot_changed", reason=str(error))
                        write_json(pending_state_path, pending_state)
                write_json(progress, {"status": "snapshot_changed", "reason": str(error), "at": time.time()})
                return 2

            run_id = arm["run_id"]
            native = arm["mode"] == "native-only"
            env = os.environ.copy()
            env.update(KERNELBENCH_REPO=str(ROOT), KERNELBENCH_BACKEND="cuda" if native else "tilelang",
                       KERNELBENCH_KERNEL_LANGUAGE="cuda" if native else "tilelang",
                       KERNELBENCH_AGENT_MODEL=manifest["model"], KERNELBENCH_DEVICE=manifest["device"],
                       KERNELBENCH_REMOTE_PYTHON=manifest["python"],
                       CUDA_VISIBLE_DEVICES=manifest["device"].split(":", 1)[1],
                       TORCH_EXTENSIONS_DIR=str(state_file.parent / "torch_extensions"))
            env["PATH"] = f"{Path(manifest['python']).parent}:{env.get('PATH', '')}"
            hardware_at_start = wait_for_gpu(manifest["device"], progress, arm)
            try:
                verify_snapshot(manifest)
            except Exception as error:
                for pending in manifest["arms"]:
                    pending_state_path = state_path(pending)
                    pending_state = json.loads(pending_state_path.read_text())
                    if pending_state.get("status") == "queued":
                        pending_state.update(status="incomplete", phase="snapshot_changed", reason=str(error))
                        write_json(pending_state_path, pending_state)
                write_json(progress, {"status": "snapshot_changed", "reason": str(error), "at": time.time()})
                return 2
            if not preflight_done:
                write_json(progress, {"status": "timing_preflight", "device": manifest["device"], "at": time.time()})
                try:
                    timing_preflight(manifest, manifest_path.parent, env)
                except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
                    for pending in manifest["arms"]:
                        failed = json.loads(state_path(pending).read_text())
                        failed.update(status="incomplete", phase="timing_preflight_failed", reason=str(error))
                        write_json(state_path(pending), failed)
                    write_json(progress, {"status": "timing_preflight_failed", "reason": str(error), "at": time.time()})
                    return 2
                preflight_done = True
            write_json(progress, {"status": "running", "run_id": run_id, "mode": arm["mode"],
                                  "hardware_at_start": hardware_at_start, "at": time.time()})
            command = [manifest["python"], str(ROOT / "thirdparty/KernelBench/scripts/run_remote.py"),
                       run_id, manifest["task"], arm["mode"], "full"]
            with (state_file.parent / "worker.log").open("w") as log:
                try:
                    result = subprocess.run(command, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                            stdout=log, stderr=subprocess.STDOUT, check=False)
                    returncode = result.returncode
                except OSError as error:
                    log.write(f"runner could not start: {error}\n")
                    returncode = 127
            final_state = json.loads(state_file.read_text())
            try:
                hardware_at_end = hardware_snapshot(manifest["device"])
            except (OSError, RuntimeError, subprocess.SubprocessError) as error:
                hardware_at_end = {"unavailable": str(error), "observed_at": time.time()}
            final_state["hardware_at_start"] = hardware_at_start
            final_state["hardware_at_end"] = hardware_at_end
            if final_state.get("status") not in TERMINAL or (returncode != 0 and final_state.get("status") == "complete"):
                final_state.update(status="incomplete", phase="runner_exit",
                                   reason=f"runner exited {returncode} without a consistent terminal state")
            write_json(state_file, final_state)
            write_json(progress, {"status": "queued_next", "last_run_id": run_id,
                                  "last_status": final_state["status"],
                                  "hardware_at_start": hardware_at_start,
                                  "hardware_at_end": hardware_at_end, "at": time.time()})
        write_json(progress, {"status": "complete", "at": time.time(),
                              "arms": [{"run_id": arm["run_id"],
                                        "status": json.loads(state_path(arm).read_text())["status"]}
                                       for arm in manifest["arms"]]})
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("operation", choices=("prepare", "run"))
    parser.add_argument("--manifest", type=Path, required=True)
    args = parser.parse_args()
    manifest = read_manifest(args.manifest)
    if args.operation == "prepare":
        prepare(manifest)
        return 0
    return run(manifest, args.manifest)


if __name__ == "__main__":
    raise SystemExit(main())
