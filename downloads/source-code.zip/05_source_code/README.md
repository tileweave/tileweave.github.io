# TileWeave source code

`kernelopt/`, `native/`, and `scripts/` contain workflow interfaces, platform backends, evaluation support, native runtime code, and execution entry points. Shared support files are retained where the Ascend and ROCm execution tools import them.

`skills/tileweave/SKILL.md` and `skills/tileweave/ITERATIONS.md` define the agent policy. `KDA_REFERENCE.md` provides the fixed upstream version, download commands and invocation examples. `scripts/submit_kda_pair.py` and `kernelopt/protocol/kda_workflow.py` provide the local KDA/KDA+TileWeave invocation path; upstream workflow resources are supplied through `KDA_SOURCE_DIR`. `IMPLEMENTATION_NOTES.md` maps the main interfaces and case records; `ARM_CAPABILITIES.md` summarizes the comparison definitions.

Candidate source snapshots and their original execution records are in the MLP and MinGPT case directories. Compiler/runtime dependencies and model services are selected by the platform execution configuration.

## Protocol entry points

The Ascend and ROCm backend evaluators separate 30 correctness trials from one timing block: three warmups, five timed calls, and timing input seed 42. Reference and candidate use the same protocol. Ascend reports the msprof device-task envelope (last completion minus first start); ROCm reports the HIP event interval around forward. Both include gaps and count overlapping time once, but their boundary definitions differ. Per-task duration sums remain diagnostic only in these evaluators. MLP and MinGPT retain the evaluators and timing protocols from their original runs, described in `../00_paper_protocol/CASE_PROTOCOLS.md`.

For a 120-minute total limit, `scripts/run_with_paper_budget.py --record /path/to/budget.json -- <foreground-workflow-command>` supervises the foreground process group on the accelerator host. Launch scripts, platform configuration, and case records document execution settings.

## Publication scope

KDA upstream resources remain external. The local dedicated launcher, workflow adaptation, candidate-tree support and two attention reference adapters are included; see `KDA_REFERENCE.md`. The main platform evaluators and Ours/Random/Fixed/Native execution support accompany the original case snapshots.

Bundled reference workloads, baseline workflow resources, platform links, and remaining configuration requirements are listed in `DEPENDENCIES.md`. `BUNDLED_DEPENDENCIES.json` inventories the retained dependency files.

## Random and KDA entry points

`RANDOM_ROUTING.md` describes the tool-sampled action and the agent's choice of a retained correct High source after Rollback. Run the routing commands inside the experiment workspace prepared by the launcher.

`configs/kda_cohort.json` maps all 50 Level-3 workloads to the references used by the KDA launcher. `check-all` validates those mappings and renders per-task prompts; `KDA_REFERENCE.md` documents the commands and optional configuration export.

The case directories retain their run-specific source snapshots. The endpoint convention and separate final-verification fields are described in `../00_paper_protocol/ENDPOINT_DEFINITION.md`.

Random uses a 7,200-second foreground supervisor and accelerator/model rates from `configs/random_routing.json`. `--check-config` displays the settings; `random-run-manifest.json` links execution artifacts. See `RANDOM_ROUTING.md` for usage.
